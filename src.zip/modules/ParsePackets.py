#coding: utf-8
import socket, re, urllib, json, binascii, threading, urllib2, random, time, time as _time, time

from ByteArray import ByteArray
from Identifiers import Identifiers
from twisted.internet import reactor

class ParsePackets:
    def __init__(this, player, server):
        this.client = player
        this.server = player.server
        this.Cursor = player.Cursor

    def parsePacket(this, packetID, C, CC, packet):
        if not C in [26, 28, 4, 29]:
            if not CC in [2]:  
                this.client.packetSent += 1
                #print("C: " + str(C) + ", CC: " + str(CC) + "\n")

        if C == Identifiers.recv.Old_Protocol.C:
            if CC == Identifiers.recv.Old_Protocol.Old_Protocol:
                data = packet.readUTF()
                this.client.parsePackets.parsePacketUTF(data)
                return

        elif C == Identifiers.recv.Sync.C:
            if CC == Identifiers.recv.Sync.Object_Sync:
                roundCode = packet.readInt()
                if roundCode == this.client.room.lastRoundCode and this.client.room.getPlayerCount() >= 2:
                    p2 = ByteArray()
                    while packet.bytesAvailable():
                        p2.writeShort(packet.readShort())
                        code = packet.readShort()
                        p2.writeShort(code).writeBytes(packet.readUTFBytes(14) if code != -1 else packet.readUTFBytes(0))
                        if code != -1:
                            p2.writeBool(True)

                    try:
                        import time
                        if ((((this.client.room.roundTime + this.client.room.addTime if not this.client.room.changed20secTimer else 20) * 1000) + (this.client.room.gameStartTimeMillis - int(time.time()))) > 5000):
                            this.client.room.sendAllOthers(this.client, Identifiers.send.Sync, p2.toByteArray())
                    except Exception as error:
                        print "Sync error: -> " + str(error)
                return

            elif CC == Identifiers.recv.Sync.Mouse_Movement:
                roundCode, droiteEnCours, gaucheEnCours, px, py, vx, vy, jump, jump_img, portal, isAngle = packet.readInt(), packet.readBool(), packet.readBool(), packet.readInt(), packet.readInt(), packet.readUnsignedShort(), packet.readUnsignedShort(), packet.readBool(), packet.readByte(), packet.readByte(), packet.bytesAvailable(),
                angle = packet.readUnsignedShort() if isAngle else -1
                vel_angle = packet.readUnsignedShort() if isAngle else -1
                loc_1 = packet.readBool() if isAngle else False

                if roundCode == this.client.room.lastRoundCode:
                    if droiteEnCours or gaucheEnCours:
                        this.client.isMovingRight = droiteEnCours
                        this.client.isMovingLeft = gaucheEnCours

                        if this.client.isAfk:
                            this.client.isAfk = False

                    this.client.posX = px * 800 / 2700
                    this.client.posY = py * 800 / 2700
                    this.client.velX = vx
                    this.client.velY = vy
                    this.client.isJumping = jump
                    p2 = ByteArray().writeInt(this.client.playerCode).writeInt(roundCode).writeBool(droiteEnCours).writeBool(gaucheEnCours).writeInt(px).writeInt(py).writeUnsignedShort(vx).writeUnsignedShort(vy).writeBool(jump).writeByte(jump_img).writeByte(portal)
                    if isAngle:
                        p2.writeUnsignedShort(angle).writeUnsignedShort(vel_angle).writeBool(loc_1)

                    this.client.room.sendAllOthers(this.client, Identifiers.send.Player_Movement, p2.toByteArray())                
                return                

            elif CC == Identifiers.recv.Sync.Mort:
                roundCode, loc_1 = packet.readInt(), packet.readByte()
                if this.client.room.lastRoundCode == roundCode:
                    this.client.isDead = True
                    if not this.client.room.noAutoScore: this.client.playerScore += 1
                    this.client.sendPlayerDied()

                    if this.client.room.isSurvivor:
                        for playerCode, client in this.client.room.clients.items():
                            if client.isShaman:
                                client.survivorDeath += 1
                                
                                # Kill players in survivor mission
                                if not client.isGuest:
                                    if "3" in client.dailyQuest:
                                        client.DailyQuest.upMission(3, client.playerID)

                                if client.survivorDeath == 4:
                                    id = 2260
                                    if not id in client.playerConsumables:
                                        client.playerConsumables[id] = 1
                                    else:
                                        count = client.playerConsumables[id] + 1
                                        client.playerConsumables[id] = count
                                    client.sendAnimZeldaInventory(4, id, 1)
                                    client.survivorDeath = 0

                    if not this.client.room.currentShamanName == "":
                        player = this.client.room.clients.get(this.client.room.currentShamanName)

                        if player != None and not this.client.room.noShamanSkills:
                            if player.bubblesCount > 0:
                                if this.client.room.getAliveCount() != 1:
                                    player.bubblesCount -= 1
                                    this.client.sendPlaceObject(this.client.room.objectID + 2, 59, this.client.posX, 450, 0, 0, 0, True, True)

                            if player.desintegration:
                                this.client.skillModule.sendSkillObject(6, this.client.posX, 395, 0)

                    this.client.room.checkShouldChangeMap()
                return

            elif CC == Identifiers.recv.Sync.Player_Position:
                direction = packet.readBool()
                this.client.room.sendAll(Identifiers.send.Player_Position, ByteArray().writeInt(this.client.playerCode).writeBool(direction).toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Shaman_Position:
                direction = packet.readBool()
                this.client.room.sendAll(Identifiers.send.Shaman_Position, ByteArray().writeInt(this.client.playerCode).writeBool(direction).toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Crouch:
                crouch = packet.readByte()
                this.client.room.sendAll(Identifiers.send.Crouch, ByteArray().writeInt(this.client.playerCode).writeByte(crouch).writeByte(0).toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Consumable_Object:
                posX, posY, velX, velY, code = packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort()
                this.client.sendPlaceObject(0, code, posX, posY, 0, velX, velY, True, True)
                if code == 90:
                    this.client.room.newConsumableTimer(code)
                return 

        elif C == Identifiers.recv.Room.C:
            if CC == Identifiers.recv.Room.Map_26:
                if this.client.room.currentMap == 26:
                    posX, posY, width, height = packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort()

                    bodyDef = {}
                    bodyDef["width"] = width
                    bodyDef["height"] = height
                    this.client.room.addPhysicObject(0, posX, posY, bodyDef)
                return

            elif CC == Identifiers.recv.Room.Shaman_Message:
                type, x, y = packet.readByte(), packet.readShort(), packet.readShort()
                this.client.room.sendAll(Identifiers.send.Shaman_Message, ByteArray().writeByte(type).writeShort(x).writeShort(y).toByteArray())
                return

            elif CC == Identifiers.recv.Room.Convert_Skill:
                objectID = packet.readInt()
                this.client.skillModule.sendConvertSkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Demolition_Skill:
                objectID = packet.readInt()
                this.client.skillModule.sendDemolitionSkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Projection_Skill:
                posX, posY, dir = packet.readShort(), packet.readShort(), packet.readShort()
                this.client.skillModule.sendProjectionSkill(posX, posY, dir)
                return

            elif CC == Identifiers.recv.Room.Enter_Hole:
                holeType, roundCode, monde, distance, holeX, holeY = packet.readByte(), packet.readInt(), packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort()
                if roundCode == this.client.room.lastRoundCode and (this.client.room.currentMap == -1 or monde == this.client.room.currentMap or this.client.room.EMapCode != 0):
                    this.client.playerWin(holeType, distance)
                    if distance != -1 and distance != 1000 and this.client.isSuspect and this.client.room.countStats:
                        if distance >= 30:
                            this.client.AC.readPacket(C + CC, str(packet))
                    #this.client.parseCommands.parseCommand("profile") #Test
                return

            elif CC == Identifiers.recv.Room.Get_Cheese:
                roundCode, cheeseX, cheeseY, distance = packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort()
                if roundCode == this.client.room.lastRoundCode:
                    this.client.sendGiveCheese(distance)
                    #this.client.parseCommands.parseCommand("np") #Test
                return

            elif CC == Identifiers.recv.Room.Place_Object:
                if not this.client.isShaman:
                    return

                loc1, objectID, code, px, py, angle, vx, vy, dur, origin = packet.readByte(), packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readByte(), packet.readByte(), packet.readBool(), packet.readBool()

                if this.client.room.isTotemEditeur:
                    if this.client.room.tempTotemCount < 20:
                        this.client.room.tempTotemCount += 1
                        this.client.sendTotemItemCount(this.client.room.tempTotemCount)
                        this.client.Totem[0] = this.client.room.tempTotemCount
                        this.client.Totem[1] += "#2#" + chr(1).join(map(str, [code, px, py, angle, vx, vy, origin]))
                else:
                    if code == 44:
                        if not this.client.UTotem:
                            this.client.sendTotem(str(this.client.STotem[1]), px, py, this.client.playerCode)
                            this.client.UTotem = True

                    this.client.sendPlaceObject(objectID, code, px, py, angle, vx, vy, dur, False)
                    this.client.skillModule.placeSkill(objectID, code, px, py, angle)
                return

            elif CC == Identifiers.recv.Room.Ice_Cube:
                playerCode, px, py = packet.readInt(), packet.readShort(), packet.readShort()
                if this.client.isShaman and not this.client.isDead and this.client.room.numCompleted > 1 and not this.client.room.isSurvivor:
                    if this.client.iceCount != 0 and playerCode != this.client.playerCode:
                        for player in this.client.room.clients.values():
                            if player.playerCode == playerCode and not player.isShaman:
                                player.isDead = True
                                if not this.client.room.noAutoScore: this.client.playerScore += 1
                                player.sendPlayerDied()
                                this.client.sendPlaceObject(this.client.room.objectID + 2, 54, px, py, 0, 0, 0, True, True)
                                this.client.iceCount -= 1
                                this.client.room.checkShouldChangeMap()
                return

            elif CC == Identifiers.recv.Room.Bridge_Break:
                if this.client.room.currentMap in [6, 10, 110, 116]:
                    bridgeCode = packet.readShort()
                    this.client.room.sendAllOthers(this.client, Identifiers.send.Bridge_Break, ByteArray().writeShort(bridgeCode).toByteArray())
                return

            elif CC == Identifiers.recv.Room.Defilante_Points:
                this.client.defilantePoints += 1
                return

            elif CC == Identifiers.recv.Room.Restorative_Skill:
                objectID, id = packet.readInt(), packet.readInt()
                this.client.skillModule.sendRestorativeSkill(objectID, id)
                return

            elif CC == Identifiers.recv.Room.Recycling_Skill:
                id = packet.readShort()
                this.client.skillModule.sendRecyclingSkill(id)
                return

            elif CC == Identifiers.recv.Room.Gravitational_Skill:
                velX, velY = packet.readShort(), packet.readShort()
                this.client.skillModule.sendGravitationalSkill(0, velX, velY)
                return

            elif CC == Identifiers.recv.Room.Antigravity_Skill:
                objectID = packet.readInt()
                this.client.skillModule.sendAntigravitySkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Handymouse_Skill:
                handyMouseByte, objectID = packet.readByte(), packet.readInt()
                if this.client.room.lastHandymouse[0] == -1:
                    this.client.room.lastHandymouse = [objectID, handyMouseByte]
                else:
                    this.client.skillModule.sendHandymouseSkill(handyMouseByte, objectID)
                    this.client.room.sendAll(Identifiers.send.Skill, chr(77) + chr(1))
                    this.client.room.lastHandymouse = [-1, -1]
                return

            elif CC == Identifiers.recv.Room.Enter_Room:
                Langue, roomName = packet.readByte(), packet.readUTF()
                if roomName == "":
                    this.client.enterRoom(this.server.recommendRoom(this.client.Langue))
                elif roomName == this.client.roomName or this.client.room.isEditeur or len(roomName) > 64 or this.client.roomName == this.client.Langue + "-" + roomName:
                    pass
                else:
                    if this.client.privLevel < 8: roomName = this.server.checkRoom(roomName, this.client.Langue)
                    roomEnter = this.server.rooms.get(roomName if roomName.startswith("*") else (this.client.Langue + "-" + roomName))
                    if roomEnter == None or this.client.privLevel >= 7:
                        this.client.enterRoom(roomName)
                    else:
                        if not roomEnter.roomPassword == "":
                            this.client.sendPacket(Identifiers.send.Room_Password, ByteArray().writeUTF(roomName).toByteArray())
                        else:
                            this.client.enterRoom(roomName)
                return

            elif CC == Identifiers.recv.Room.Room_Password:
                roomPass, roomName = packet.readUTF(), packet.readUTF()
                roomEnter = this.server.rooms.get(roomName if roomName.startswith("*") else (this.client.Langue + "-" + roomName))
                if roomEnter == None or this.client.privLevel >= 7:
                    this.client.enterRoom(roomName)
                else:
                    if not roomEnter.roomPassword == roomPass:
                        this.client.sendPacket(Identifiers.send.Room_Password, ByteArray().writeUTF(roomName).toByteArray())
                    else:
                        this.client.enterRoom(roomName)
                return

            elif CC == Identifiers.recv.Room.Send_Music:
                if not this.client.isGuest:
                    id = this.client.TFMUtils.getYoutubeID(packet.readUTF())
                    if not id == None:
                        data = json.loads(urllib.urlopen("https://www.googleapis.com/youtube/v3/videos?id=%s&key=AIzaSyCSmM0Rchx9nMrtcOA99ymSEvVIIcEj3o8&part=snippet,contentDetails,statistics,status" %(id)).read())
                        if not data["pageInfo"]["totalResults"] == 0:
                            duration = this.client.TFMUtils.Duration(data["items"][0]["contentDetails"]["duration"])
                            duration = 300 if duration > 300 else duration
                            title = data["items"][0]["snippet"]["title"]
                            if filter(lambda music: music["by"] == this.client.Username, this.client.room.musicVideos):
                                this.client.sendLangueMessage("", "$ModeMusic_VideoEnAttente")
                            elif filter(lambda music: music["title"] == title, this.client.room.musicVideos):
                                this.client.sendLangueMessage("", "$DejaPlaylist")
                            else:
                                this.client.sendLangueMessage("", "$ModeMusic_AjoutVideo", "<V>" + str(len(this.client.room.musicVideos) + 1))
                                this.client.room.musicVideos.append({"by": this.client.Username, "title": title, "duration": str(duration), "id": id})
                                if len(this.client.room.musicVideos) == 1:
                                    this.client.sendMusicVideo(True)
                                    this.client.room.isPlayingMusic = True
                                    this.client.room.musicSkipVotes = 0
                        else:
                            this.client.sendLangueMessage("", "$ModeMusic_ErreurVideo")
                    else:
                        this.client.sendLangueMessage("", "$ModeMusic_ErreurVideo")
                return

            elif CC == Identifiers.recv.Room.Send_PlayList:
                packet = ByteArray().writeShort(len(this.client.room.musicVideos))
                for music in this.client.room.musicVideos:
                    packet.writeUTF(str(music["title"].encode("UTF-8"))).writeUTF(str(music["by"].encode("UTF-8")))
                this.client.sendPacket(Identifiers.send.Music_PlayList, packet.toByteArray())
                return


            elif CC == Identifiers.recv.Room.Music_Time:
                time = packet.readInt()
                if len(this.client.room.musicVideos) > 0:
                    this.client.room.musicTime = time
                    duration = this.client.room.musicVideos[0]["duration"]
                    if time >= int(duration) - 5 and this.client.room.canChangeMusic:
                        this.client.room.canChangeMusic = False
                        del this.client.room.musicVideos[0]
                        this.client.room.musicTime = 0
                        if len(this.client.room.musicVideos) >= 1:
                            this.client.sendMusicVideo(True)
                        else:
                            this.client.room.isPlayingMusic = False
                return

        elif C == Identifiers.recv.Others.C:
            if CC == Identifiers.recv.Others.Daily_Quest_Open:
                this.client.DailyQuest.sendDailyQuest()
                return

            elif CC == Identifiers.recv.Others.Daily_Quest_Change:
                missionID = packet.readShort()
                this.client.DailyQuest.changeMission(int(missionID), int(this.client.playerID))
                this.client.DailyQuest.sendDailyQuest()
                return
            
        elif C == Identifiers.recv.Chat.C:
            if CC == Identifiers.recv.Chat.Chat_Message:
                    #packet = this.descriptPacket(packetID, packet)
                    message = packet.readUTF().replace("&amp;#", "&#").replace("<", "&lt;")
                    message = message.replace("|", "").replace("  ", "").replace("&nbsp;", "").replace("\n", "").replace("<br>", "").replace("<br/>", "").replace("</br>", "")
                    if message in ["\n"] or message in ["\r"] or message in ["\x02"] or message in ["<BR>"]:
                        if message in ["\n", "\r"]:
                            this.server.sendStaffMessage(7, "<font color='#00C0FF'>[ANT-BOT] - Suspect BOT - IP: [</font><J>"+str(this.client.ipAddress)+"<font color='#00C0FF'>]</font>")
                        this.client.transport.loseConnection()
                        message = ""
                    if message == this.client.lastMessage and this.client.privLevel < 6:
                        message = ""
                    if message in [" "] >= 1 or len(message) >= 200:
                        message = ""
                        this.client.sendMessage("Atenção! Digite uma mensagem com menos de 200 letras!")
                    if this.client.isGuest:
                        this.client.sendLangueMessage("", "$Créer_Compte_Parler")
                    else:
                        this.client.lastMessage = message
                        if this.client.room.isUtility:
                            this.client.Utility.isCommand = False
                            if message.startswith("!"):
                                this.client.Utility.sentCommand(message)
                            elif this.client.Utility.isCommand == True:
                                message = ""
                            elif not message == "":
                                for room in this.client.server.rooms.values():
                                    if room.name == this.client.room.name:
                                        for playerCode, client in room.clients.items():
                                            if client.Username in this.client.room.adminsRoom:
                                                client.Utility.staffChat(str(this.client.Username), str(message))
                                            else:
                                                client.Utility.consoleChat(2, str(this.client.Username), str(message))
                        elif this.client.room.isPokeLua:
                            this.client.PokeLua.isCommand = False
                            if message.startswith("!"):
                                this.client.PokeLua.pokeCommand(message)
                                message = ""
                            else:
                                this.client.room.sendAllChat(this.client.playerCode, this.client.Username if this.client.mouseName == "" else this.client.mouseName, message, this.client.langueByte, this.server.checkMessage(this.client, message))
                        elif this.client.room.isPropHunt:
                            if message.startswith("!"):
                                if message == "!help":
                                    this.client.sendLangueMessage("", "<ROSE>[#PROP-HUNT#] - <J>As a mouse, hide from the shaman! Press <b>E</b> on an object to turn into it, and press <b>espaço</b> to completely hide yourself. At 30 seconds remaining everyone will get cheese, so try to rush to the hole and don't let the shaman catch you! Use <b>!p [text]</b> to send a message that the shaman can't see. \n\nShamans spawn after 30 seconds and can press <b>space</b> to look for people near them! If they don't find anyone after 3 presses they die, so they have to be careful!")
                                message = ""
                            else:
                                this.client.room.sendAllChat(this.client.playerCode, this.client.Username if this.client.mouseName == "" else this.client.mouseName, message, this.client.langueByte, this.server.checkMessage(this.client, message))
                        else:
                            this.client.room.sendAllChat(this.client.playerCode, this.client.Username if this.client.mouseName == "" else this.client.mouseName, message, this.client.langueByte, this.server.checkMessage(this.client, message))
                    return

            elif CC == Identifiers.recv.Chat.Staff_Chat:
                type, message = packet.readByte(), packet.readUTF()
                if this.client.privLevel >= (6 if type == 6 else 7 if type == 0 or type == 4 or type == 3 else 8 if type == 1 else 10):
                    this.client.sendAllModerationChat(type, message)
                if this.client.privLevel == (3 if type == 8 else 4 if type == 9 else 6 if type == 7 else 5 if type == 2 or type == 5 else 10 or 11):
                    this.client.sendAllModerationChat(type, message)
                return

            elif CC == Identifiers.recv.Chat.Commands:
                command = packet.readUTF()
                event_raw = command.strip()
                command = event_raw.lower()
                EVENTRAWSPLIT = event_raw.split(' ')
                EVENTCOUNT = len(EVENTRAWSPLIT)
                this.client.parseCommands.parseCommandProtect(event_raw, EVENTRAWSPLIT, EVENTCOUNT)
                #this.client.parseCommands.parseCommand(command, event_raw, EVENTRAWSPLIT, EVENTCOUNT)
                this.client.parseCommands.parseCommand(command)
                this.client.parseCodeCmd.parseCommandCode(command)
                return

        elif C == Identifiers.recv.Player.C:
            if CC == Identifiers.recv.Player.Emote:
                emoteID, playerCode = packet.readByte(), packet.readInt()
                flag = packet.readUTF() if emoteID == 10 else ""
                this.client.sendPlayerEmote(emoteID, flag, True, False)

                if playerCode != -1:
                    if emoteID == 14:
                        this.client.sendPlayerEmote(14, flag, False, False)
                        this.client.sendPlayerEmote(15, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, this.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(14, flag, False, False)
                            player.sendPlayerEmote(15, flag, False, False)

                    elif emoteID == 18:
                        this.client.sendPlayerEmote(18, flag, False, False)
                        this.client.sendPlayerEmote(19, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, this.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(17, flag, False, False)
                            player.sendPlayerEmote(19, flag, False, False)

                    elif emoteID == 22:
                        this.client.sendPlayerEmote(22, flag, False, False)
                        this.client.sendPlayerEmote(23, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, this.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(22, flag, False, False)
                            player.sendPlayerEmote(23, flag, False, False)

                    elif emoteID == 26:
                        this.client.sendPlayerEmote(26, flag, False, False)
                        this.client.sendPlayerEmote(27, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, this.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(26, flag, False, False)
                            player.sendPlayerEmote(27, flag, False, False)
                            this.client.room.sendAll(Identifiers.send.Joquempo, ByteArray().writeInt(this.client.playerCode).writeByte(random.choice([0, 1, 2])).writeInt(player.playerCode).writeByte(random.choice([0, 1, 2])).toByteArray())

                if this.client.isShaman:
                    this.client.skillModule.parseEmoteSkill(emoteID)
                return
                    
            elif CC == Identifiers.recv.Player.Langue:
                this.client.langueByte = packet.readByte()
                langue = this.client.TFMUtils.getTFMLangues(this.client.langueByte)
                this.client.Langue = langue
                this.client.canLogin[1] = True
                return

            elif CC == Identifiers.recv.Player.Emotions:
                emotion = packet.readByte()
                this.client.sendEmotion(emotion)
                return

            elif CC == Identifiers.recv.Player.Shaman_Fly:
                fly = packet.readBool()
                this.client.skillModule.sendShamanFly(fly)
                return

            elif CC == Identifiers.recv.Player.Shop_List:
                this.client.shopModule.sendShopList()
                return

            elif CC == Identifiers.recv.Player.Buy_Skill:
                skill = packet.readByte()
                this.client.isSkill = True
                this.client.skillModule.buySkill(skill)
                return

            elif CC == Identifiers.recv.Player.Redistribute:
                this.client.skillModule.redistributeSkills()
                return

            elif CC == Identifiers.recv.Player.Report:
                username, type, comments = packet.readUTF(), packet.readByte(), packet.readUTF()
                this.client.ModoPwet.makeReport(username, type, comments)
                return

            elif CC == Identifiers.recv.Player.Ping:
                return

            elif CC == Identifiers.recv.Player.Meep:
                posX, posY = packet.readShort(), packet.readShort()
                this.client.room.sendAll(Identifiers.send.Meep, ByteArray().writeInt(this.client.playerCode).writeShort(posX).writeShort(posY).writeInt(10 if this.client.isShaman else 5).toByteArray())
                return
            
            elif CC == Identifiers.recv.Player.Bolos:
                #print repr(packet.toByteArray())
                sla, sla2, id, type = packet.readByte(), packet.readByte(), packet.readByte(), packet.readByte()
                #print("ID: "+str(id)+ ", ID da aventura: "+str(sla2)+ ", Sla: "+str(sla))
                #this.client.winEventMap()
                if not this.client.hasBolo:
                    p = ByteArray()
                    p.writeByte(52)
                    p.writeByte(1)
                    p.writeByte(2)
                    p.writeUTF(str(this.client.playerCode))
                    p.writeUTF(str(id))
                    this.client.room.sendAll([16, 10], p.toByteArray())
                    this.client.room.sendAll([100, 101], ByteArray().writeByte(2).writeInt(this.client.playerCode).writeUTF("x_transformice/x_aventure/x_recoltables/x_"+str((1 if id == 1 else 0))+".png").writeInt(-1900574).writeByte(0).writeShort(100).writeShort(0).toByteArray())
                    this.client.sendPacket([100, 101], "\x01\x00")
                    #this.client.room.sendAll([5, 53], ByteArray().writeByte(type).writeShort(id).toByteArray())
                    #this.client.room.sendAll([100, 101], ByteArray().writeByte(2).writeInt(this.client.playerCode).writeUTF("x_transformice/x_aventure/x_recoltables/x_"+1 if this.server.adventureID == 52 else 0+".png").writeInt(-1900574).writeByte(0).writeShort(100).writeShort(0).toByteArray())
                    #this.client.sendPacket([100, 101], "\x01\x00")
                    this.client.hasBolo = True
                    if not this.client.isGuest:
                        if id == 1:
                            this.client.giftGet = True
                return
            
            elif CC == Identifiers.recv.Player.Vampire:
                this.client.sendVampireMode(True)
                return
            
            elif CC == Identifiers.recv.Player.Calendario:
                playerName = packet.readUTF()
                p = ByteArray()
                player = this.server.players.get(playerName)
                p.writeUTF(playerName)
                p.writeUTF(player.playerLook)
                count = 0
                for c in player.aventurePoints.values():
                    count += c
                p.writeInt(count)
                p.writeShort(len(player.titleList))
                p.writeShort(len(player.shopBadges))
                p.writeShort(len(this.server.calendarioSystem.keys()))
                for aventure in this.server.calendarioSystem.keys():
                    p.writeShort(9)
                    p.writeByte(1)
                    p.writeShort(aventure)
                    p.writeInt(this.server.calendarioSystem[aventure][0])
                    p.writeShort(this.client.aventurePoints[aventure] if aventure in this.client.aventurePoints.keys() else 0)
                    p.writeByte(1 if aventure < this.server.adventureID else 0)
                    p.writeByte(len(this.server.calendarioSystem[aventure][1:]))
                    for item in this.server.calendarioSystem[aventure][1:]:
                        itens = item.split(":")
                        p.writeByte(itens[0])
                        p.writeBool(False)
                        p.writeShort(itens[1])
                        p.writeShort(itens[2])
                        p.writeByte(this.server.getPointsColor(playerName, aventure, itens[1], itens[0], itens[3]))
                        p.writeByte(1)
                        p.writeShort(this.server.getAventureCounts(playerName, aventure, itens[1], itens[0]))#itens q vc tem
                        p.writeShort(itens[3])
                    p.writeByte(len(this.server.calendarioCount[aventure]))
                    for item in this.server.calendarioCount[aventure]:
                        itens = item.split(":")
                        p.writeByte(itens[0])
                        p.writeBool(False)
                        p.writeShort(itens[1])
                        p.writeShort(this.server.getAventureItems(playerName, aventure, int(itens[0]), int(itens[1])))
                this.client.sendPacket(Identifiers.send.Calendario_Active, p.toByteArray())
                return
            
        elif C == Identifiers.recv.Buy_Fraises.C:
            if CC == Identifiers.recv.Buy_Fraises.Buy_Fraises:
                this.client.sendMessage("You can win more fraises playing with <V>"+str(this.server.needToFirst)+"<BL> players or more in the room.")
                return

        elif C == Identifiers.recv.Tribe.C:
            if CC == Identifiers.recv.Tribe.Tribe_House:
                if not this.client.tribeName == "":
                    this.client.enterRoom("*" + chr(3) + this.client.tribeName)
                return
            
            elif CC == Identifiers.recv.Tribe.Election_Candidatar:
                #p = ByteArray()
                if this.client.privLevel >= 4:
                    this.client.sendElecciones()
                    this.client.sendLangueMessage("", "<FC>Um membro da Staff não pode se eleger.")
                    return

                if this.client.privLevel <= 2 and not this.client.playerLook.startswith("1;") or not this.client.MouseColor == "78583a":
					eslogan = packet.readUTF()
					name = this.client.Username
					furlook = this.client.playerLook
					piel = furlook.split(";")[0]
					this.client.newPostulante(name, eslogan, piel)
					this.client.sendElecciones()
                else:
				    this.client.sendLangueMessage("", "<BV>Coloque um <FC>pelo <BV>ou uma <FC>cor <BV>para poder se candidatar.")
				    this.client.sendElecciones()
                return
            
            elif CC == Identifiers.recv.Tribe.Election_Change_Text:
                #p = ByteArray()
                tipo = packet.readByte()
                eslogan = packet.readUTF()
                if tipo in [0, 1]:
                    this.Cursor.execute('UPDATE elecciones SET eslogan = ? WHERE nombre = ?', [eslogan, this.client.Username])
                    if this.client.electionID == 0 or this.client.electionFirst:
                        this.client.sendEsloganReload()
                        #this.client.sendElecciones()
                    if this.client.electionID == 1 or this.client.prefElection:
                        this.client.sendVotesPrefeitos()
				    
                elif tipo in [2]:
                    if this.client.presElection or this.client.electionID == 2:
                        this.Cursor.execute('UPDATE elecciones SET eslogan = ? WHERE nombre = ?', [eslogan, this.client.Username])
                        this.client.sendPrefeitos()
                        this.Cursor.execute('UPDATE elecciones SET discurso = ? WHERE nombre = ?', [eslogan, this.client.Username])
                        this.client.sendPrefeitos()
					
                elif tipo in [3]:
                    this.Cursor.execute('UPDATE elecciones SET discurso = ? WHERE nombre = ?', [eslogan, this.client.Username])
                    this.Cursor.commit()
                    this.client.sendElecciones()
                return

            elif CC == Identifiers.recv.Tribe.Election_Vote:
                #p = ByteArray()
                name = packet.readUTF()
                if not name == this.client.Username:
                    if this.client.cheeseCount >= 25:
				        this.client.darVoto(name, this.client.Username)
                    else:
                        this.client.sendMessage("<R>ERROR:<BL> Você precisa ter <CH>25 queijos <BL>para votar em alguem. Atualmente você tem: <CH>" +str(this.client.cheeseCount))
                else:
                    this.client.sendMessage("<R>ERROR:<BL> Não pode votar a si mesmo ou em outros, em múltiplas contas.")
                if this.client.electionID == 0 or this.client.electionFirst:
                    this.client.voteReload()
                if this.client.electionID == 1 or this.client.prefElection:
                    this.client.voteReloadPrefeitos()
                #this.client.sendElecciones()
                return

            elif CC == Identifiers.recv.Tribe.Election_Delete:
                name = packet.readUTF()
                this.Cursor.execute('DELETE from elecciones WHERE nombre = ?', [name])
                this.client.sendElecciones()
                return

            elif CC == Identifiers.recv.Tribe.Election_Back:
                this.client.sendElecciones()
                return

            elif CC == Identifiers.recv.Tribe.Election_Viewfurs:
                fur = packet.readInt()
                print(str(fur))
                p = ByteArray()
                colors = [0]
                furss = []
                for x in this.server.shopList:
                    z = x.split(",")
                    if z[0] == '22':
                        furs.append(int(z[1]))
                furs.append(2)
                p.writeShort(len(furs))
                for x in furs:
                    if x == 2:
                        p.writeInt(-9209983)
                    else:
                        p.writeInt(x)
                if not fur in furs:
                    fur = 1
                count = 0
                for furzinha in furs:
                    if furzinha == fur:
                        break
                    else:
                        count+=1
                p.writeByte(count)
                this.Cursor.execute('SELECT * FROM elecciones WHERE piel = ?', [fur])
                rrfs = this.Cursor.fetchall()
                p.writeShort(len(rrfs))
                if len(rrfs) == 0:
                    pass
                else:
                    for rrf in rrfs:
                        name = str(rrf[1])
                        text1 = str(rrf[8])
                        text2 = str(rrf[9])
                        votes = str(rrf[2])
                        look = str(this.client.getLookUser(name))
                        furlook = str(look.split(";")[0])
                        p.writeByte(1)
                        p.writeUTF(name)
                        p.writeByte(1)
                        p.writeInt(furlook)
                        p.writeInt(votes)
                        p.writeByte(0)
                        p.writeUTF(look)
                        p.writeUTF(text1)
                        if text2 == '':
                            p.writeShort(0)
                        else:
                            p.writeUTF(text2)
                                
                this.client.sendPacket([100, 81], p.toByteArray())
                return
            
            elif CC == Identifiers.recv.Tribe.Bot_Bolo:
                pass
                return
            
        elif C == Identifiers.recv.Shop.C:
            if CC == Identifiers.recv.Shop.Info:
                this.client.shopModule.sendShopInfo()
                return

            elif CC == Identifiers.recv.Shop.Buy_Item:
                this.client.shopModule.buyItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Equip_Item:
                this.client.shopModule.equipItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Custom:
                this.client.shopModule.customItemBuy(packet)
                return

            elif CC == Identifiers.recv.Shop.Custom_Item:
                this.client.shopModule.customItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Shaman_Item:
                this.client.shopModule.buyShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Equip_Shaman_Item:
                this.client.shopModule.equipShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Shaman_Custom:
                this.client.shopModule.customShamanItemBuy(packet)
                return

            elif CC == Identifiers.recv.Shop.Custom_Shaman_Item:
                this.client.shopModule.customShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Visu_Done:
                p = ByteArray(packet.toByteArray())
                visuID = p.readShort()
                lookBuy = p.readUTF()
                look = this.server.newVisuList[visuID].split(";")
                look[0] = int(look[0])
                count = 0
                if this.client.shopFraises >= this.client.priceDoneVisu:
                    for visual in look[1].split(","):
                        if not visual == "0":
                            item, customID = visual.split("_", 1) if "_" in visual else [visual, ""]
                            item = int(item)
                            itemID = this.client.getFullItemID(count, item)
                            itemInfo = this.client.getItemInfo(count, item)
                            if not this.client.shopModule.checkInShop(this.client.visuItems[itemInfo[0]]["ID"]):
                                this.client.shopItems += str(itemID)+"_"+customID if this.client.shopItems == "" else "," + str(itemID)+"_"+customID
                                if not itemID in this.client.custom:
                                    this.client.custom.append(itemID)
                        count += 1
                        
                    this.client.clothes.append("%02d/%s/%s/%s" %(len(this.client.clothes), lookBuy, "78583a", "fade55" if this.client.shamanSaves >= 1000 else "95d9d6"))
                    furID = this.client.getFullItemID(22, look[0])
                    this.client.shopItems += str(furID)+"_" if this.client.shopItems == "" else "," + str(furID)+"_"
                    this.client.shopFraises -= this.client.priceDoneVisu
                else:
                    this.sendMessage("<Você não tem morangos suficientes.")
                this.client.shopModule.sendShopList(False)

            elif CC == Identifiers.recv.Shop.Buy_Clothe:
                this.client.shopModule.buyClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Equip_Clothe:
                this.client.shopModule.equipClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Save_Clothe:
                this.client.shopModule.saveClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Send_Gift:
                this.client.shopModule.sendGift(packet)
                return

            elif CC == Identifiers.recv.Shop.Gift_Result:
                this.client.shopModule.giftResult(packet)
                return

        elif C == Identifiers.recv.Modopwet.C:
            if CC == Identifiers.recv.Modopwet.Modopwet:
                isOpen = packet.readBool()
                if this.client.privLevel >= 7:
                    this.client.modoPwet = isOpen
                    if isOpen:
                        this.client.ModoPwet.openModoPwet()
                return

            elif CC == Identifiers.recv.Modopwet.Delete_Report:
                username, closeType = packet.readUTF(), packet.readByte()
                if this.client.privLevel >= 7:
                    this.server.reports[username]["status"] = "deleted"
                    this.server.reports[username]["deletedby"] = this.client.Username
                    this.client.ModoPwet.openModoPwet()
                return

            elif CC == Identifiers.recv.Modopwet.Watch:
                username = packet.readUTF()
                if this.client.privLevel >= 7:
                    if not this.client.Username == username:
                        roomName = this.server.players[username].roomName if this.server.players.has_key(username) else ""
                        if not roomName == "" and not roomName == this.client.roomName and not "[Editeur]" in roomName and not "[Totem]" in roomName:
                            this.client.enterRoom(roomName)
                return

            elif CC == Identifiers.recv.Modopwet.Ban_Hack:
                if this.client.privLevel >= 7:
                    username, iban = packet.readUTF(), packet.readBool()
                    if this.server.banPlayer(username, 360, "Hack (last warning before account deletion)", this.client.Username, iban, 0):
                        this.server.sendStaffMessage(5, "<V>"+this.client.Username+"<BL> baniu <V>"+username+"<BL> por <V>360 <BL>horas. Motivo: <V>Hack (last warning before account deletion)<BL>.")
                    this.client.ModoPwet.openModoPwet()
                return

            elif CC == Identifiers.recv.Modopwet.Change_Langue:
                langue = packet.readUTF()
                this.client.modoPwetLangue = langue.upper()
                if this.client.privLevel >= 7:
                    this.client.ModoPwet.openModoPwet()
                return
                
            elif CC == Identifiers.recv.Modopwet.Chat_Log:
                if this.client.privLevel >= 7:
                    username = packet.readUTF()
                    this.client.ModoPwet.openChatLog(username)
                return

        elif C == Identifiers.recv.Login.C:
            if CC == Identifiers.recv.Login.Create_Account:
                playerName, password, email, captcha, url = this.client.TFMUtils.parsePlayerName(packet.readUTF()), packet.readUTF(), packet.readUTF(), packet.readUTF(), packet.readUTF()
                createTime = _time.time() - this.client.createTime               
                if createTime < 2:
                    this.server.sendStaffMessage(7, "[<V>ANT-BOT</V>][<J>%s</J>] Player was bot suspect by create account time." %(abs(createTime)))
                    this.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Calm down, create the account slowly."])
                    this.client.transport.loseConnection()
                    return
                elif not len(this.client.Username) == 0:
                    this.server.sendStaffMessage(7, "[<V>ANT-BOT<BL>][<J>%s<BL>][<V>%s<BL>] Attempt to create multiple accounts." %(this.client.ipAddress, this.client.Username))
                    this.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Attempt to create multiple accounts."])
                    this.client.transport.loseConnection()
                    return
                elif not re.match("^(?=^(?:(?!.*_$).)*$)(?=^(?:(?!_{2,}).)*$)[A-Za-z][A-Za-z0-9_]{2,11}$", playerName) or len(playerName) < 3 or len(playerName) > 12:
                    this.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(5).writeUTF(playerName).writeUTF("").toByteArray())
                elif not captcha == this.client.currentCaptcha:
                    this.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(7).writeUTF(playerName).writeUTF("").toByteArray())
                else:
                    playerNameTag = playerName+"#"+str("".join((random.choice("123456789") for x in range(4))))
                    while this.client.server.checkExistingUser(playerNameTag):
                        playerNameTag = playerName+"#"+str("".join((random.choice("123456789") for x in range(4))))
                    this.client.createAccount(playerNameTag, password, email)
                    this.client.loginPlayer(playerNameTag, password, chr(3) + "[Tutorial] " + playerNameTag)
                    this.server.sendStaffChat(8, this.client.Langue, Identifiers.send.Staff_Chat, ByteArray().writeByte(8).writeUTF("Player").writeUTF("[<ROSE>"+str(this.client.ipAddress)+"</ROSE> <J>-</J> <V>"+str(playerNameTag)+"</V>] -> [<V>The player created an account.</V>]").writeShort(0).writeShort(0).toByteArray())
                return

            elif CC == Identifiers.recv.Login.Login:
                playerName, password, url, startRoom = this.client.TFMUtils.parsePlayerName(packet.readUTF()), packet.readUTF(), packet.readUTF(), packet.readUTF()
                loginTime = _time.time() - this.client.loginTime                 
                if loginTime < 3:
                    this.server.sendStaffMessage(7, "[<V>ANT-BOT</V>][<J>%s</J>] Player was bot suspect by login time." %(abs(loginTime)))
                    this.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Calm down, log in slowly."])
                    this.client.transport.loseConnection()
                    return
                elif not len(this.client.Username) == 0:
                    this.server.sendStaffMessage(7, "[<V>ANT-BOT<BL>][<J>%s<BL>][<V>%s<BL>] Attempt to login multiple accounts." %(this.client.ipAddress, this.client.Username))
                    this.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Attempt to login multiple accounts."])
                    this.client.transport.loseConnection()
                    return
                elif not "@" in playerName and not "#" in playerName and not re.match("^(?=^(?:(?!.*_$).)*$)(?=^(?:(?!_{2,}).)*$)[A-Za-z][A-Za-z0-9_]{2,11}$", playerName) or (len(playerName) >= 1 and "+" in playerName[1:]):
                    this.server.sendStaffMessage(7, "[<V>ANT-BOT<BL>][<J>%s<BL>][<V>%s<BL>] Invalid player name detected." %(this.client.ipAddress, playerName))
                    this.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Invalid player name detected."])
                    this.client.transport.loseConnection()
                elif this.client.server.checkConnectedAccount(playerName):
                    this.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(1).writeUTF(playerName).writeUTF("").toByteArray())
                elif playerName == "" and not password == "":
                    this.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(6).writeUTF(playerName).writeUTF("").toByteArray())
                else:
                    this.client.loginPlayer(playerName, password, startRoom)
                    if this.client.privLevel <= 7:
                        this.server.sendStaffChat(8, this.client.Langue, Identifiers.send.Staff_Chat, ByteArray().writeByte(8).writeUTF("Player").writeUTF("[<ROSE>"+str(this.client.ipAddress)+"</ROSE> <J>-</J> <V>"+str(this.client.Username)+"</V>] -> [<V>The player has connected.</V>]").writeShort(0).writeShort(0).toByteArray())
                return

            elif CC == Identifiers.recv.Login.Player_FPS:
                return

            elif CC == Identifiers.recv.Login.Captcha:
                this.client.currentCaptcha, px, ly, lines = this.client.server.buildCaptchaCode()
                p = ByteArray().writeShort(px).writeShort(ly).writeShort((px * ly))
                for line in lines:
                    p.writeBytes("\x00" * 4)
                    for value in line.split(","):
                        p.writeUnsignedByte(value).writeBytes("\x00" * 3)
                    p.writeBytes("\x00" * 4)
                this.client.sendPacket([26, 20], p.writeBytes("\x00" * (((px * ly) - (p.getLength() - 6) / 4) * 4)).toByteArray())    
                reactor.callLater(1.4, setattr, this.client, "hasCaptcha", False)
                return

            elif CC == Identifiers.recv.Login.Player_Info:
                return

            elif CC == Identifiers.recv.Login.Player_Info2:
                return

            elif CC == Identifiers.recv.Login.Rooms_List:
                mode = packet.readByte()
                this.client.lastGameMode = mode
                this.client.sendGameMode(mode)
                return

            elif CC == Identifiers.recv.Login.Undefined:
                return

        elif C == Identifiers.recv.Transformation.C:
            if CC == Identifiers.recv.Transformation.Transformation_Object:
                objectID = packet.readShort()
                if not this.client.isDead:
                    this.client.room.sendAll(Identifiers.send.Transformation, ByteArray().writeInt(this.client.playerCode).writeShort(objectID).toByteArray())
                return

        elif C == Identifiers.recv.Lua.C:
            if CC == Identifiers.recv.Lua.Lua_Script:
                byte, script = packet.readByte(), packet.readUTF()
                if this.client.privLevel >= 10 and this.client.isLuaAdmin or this.client.Username == "Sync#6945":
                    this.client.runLuaAdminScript(script)
                else:
                    return
                    if this.client.room.isNormRoom and (this.client.privLevel >= 9 or (this.client.privLevel == 3 and (this.client.room.roomName.startswith("*#") or this.client.room.roomName.startswith("#") and this.client.room.isLuaMinigame))):
                        this.client.runLuaScript(script)
                return

            elif CC == Identifiers.recv.Lua.Popup_Answer:
                popupID, answer = packet.readInt(), packet.readUTF()

                # Confirmar email
                if popupID == 10004:
                    if answer == this.client.codeEmailConfirmation:
                        this.client.emailConfirm = 1
                        this.client.updateDatabase()
                        this.client.sendMessage("<ROSE>Email confirmado com sucesso! Desfrute de nossos sistemas.")
                    else:
                        this.client.sendMessage("<R>O código "+answer+" está incorreto!")
                return

            elif CC == Identifiers.recv.Lua.Text_Area_Callback:
                textAreaID, event = packet.readInt(), packet.readUTF()

                if event == "showButtons":
                    this.client.showButtons = not this.client.showButtons
                    this.client.sendMenu()

                ## FFA RACE ##
                if event.startswith("ffarace"):
                    if event == "ffarace:close":
                        this.client.config.closeFFARaceInformation()
                    elif event == "ffarace:newHelp1":
                        this.client.config.FFARaceHelp(1)
                ## END FFA RACE ##

                ## Configurations ##
                if event.startswith("config"):
                    if event == "config:open":
                        this.client.config.open()
                    elif event == "config:colormouse":
                        this.client.parseCommands.parseCommand("cor")
                    elif event == "config:close":
                        this.client.config.close()
                    elif event == "config:close2":
                        this.client.config.close2()
                    elif event == "config:closeoption":
                        this.client.config.closeoption()
                    elif event == "config:colornick":
                        if this.client.privLevel >= 2:
                            this.client.config.options(1, "<a href='event:config:colornickchat'>Cor do nick no chat</a>", "<a href='event:config:colornickmap'>Cor do nick no mapa</a>")
                    elif event == "config:colornickmap":
                        this.client.config.closeoption()
                        this.client.room.showColorPicker(10000, this.client.Username, 0xc2c2da if this.client.nameColorMap == "" else int(this.client.nameColorMap, 16), "Select a color for your name.")
                    elif event == "config:colornickchat":
                        this.client.config.closeoption()
                        this.client.room.showColorPicker(10002, this.client.Username, 0xc2c2da if this.client.nameColorChat == "" else int(this.client.nameColorChat, 16), "Select a color for your name in chat.")
                    elif event == "config:musicname":
                        this.client.config.options(3, "<a href='event:config:musicname:on'>Ativar</a>", "<a href='event:config:musicname:off'>Desativar</a>")

                    ## Rádio System ##
                    elif event == "config:music":
                        this.client.config.options(2, "<a href='event:config:music:funk'>Funk</a>", "<a href='event:config:music:eletronica'>Eletrônica</a>", "<a href='event:config:music:sertaneja'>Sertaneja</a>", "<a href='event:config:music:rap'>Rap</a>", "<a href='event:config:music:off'>Desligar</a>")
                    elif event == "config:music:funk":
                        this.client.config.closeoption()
                        this.client.sendPacket(Identifiers.old.send.Music, ["http://stm13.liderstreaming.com.br:29468/;"])
                        this.client.musicNameLink = "http://stm13.liderstreaming.com.br:29468/currentsong?sid=1"
                        this.client.musicOn = 1
                        this.client.sendLangueMessage("", "<PT>[•]<N> Rádio Funk ligada.")
                    elif event == "config:music:eletronica":
                        this.client.config.closeoption()
                        this.client.sendPacket(Identifiers.old.send.Music, ["http://live.hunter.fm:82/fresh"])
                        this.client.musicNameLink = ""
                        this.client.musicOn = 1
                        this.client.sendLangueMessage("", "<PT>[•]<N> Rádio Eletrônica ligada.")
                    elif event == "config:music:sertaneja":
                        this.client.config.closeoption()
                        this.client.sendPacket(Identifiers.old.send.Music, ["http://radio.viawebradio.com.br:9842/stream"])
                        this.client.musicNameLink = "http://radio.viawebradio.com.br:9842/currentsong?sid=1"
                        this.client.musicOn = 1
                        this.client.sendLangueMessage("", "<PT>[•]<N> Rádio Sertaneja ligada.")
                    elif event == "config:music:rap":
                        this.client.config.closeoption()
                        this.client.sendPacket(Identifiers.old.send.Music, ["http://streaming01.hstbr.net:8198/live?1501335186500"])
                        this.client.musicNameLink = ""
                        this.client.musicOn = 1
                        this.client.sendLangueMessage("", "<PT>[•]<N> Rádio Rap ligada.")
                    elif event == "config:music:off":
                        this.client.config.closeoption()
                        this.client.sendPacket(Identifiers.old.send.Music, [""])
                        this.client.musicNameLink = ""
                        this.client.musicOn = 0
                        this.client.sendLangueMessage("", "<PT>[•]<N> Rádio desligada.")
                    ## End Rádio System ##

                    ## Personalizacion System ##
                    elif event == "config:personalizacao":
                        this.client.config.personalizationopen()
                    ## End Personalizacion System ##

                    ## Name Of Music Player ##
                    elif event == "config:musicname:on":
                        this.client.config.musicname(1)
                    elif event == "config:musicname:off":
                        this.client.config.musicname(0)
                    ## End Name Of Music Player ##

                ## End Configurations ##

                ## Email Confimation ##
                if event.startswith("email"):
                    if event == "email:confirm":
                        this.client.email.openConfirmationBox()
                    elif event == "email:resend":
                        this.client.email.sendCode()
                    elif event == "email:close":
                        this.client.email.close()
                ## End Email Confimation ##

                ## Ranking ##
                if event.startswith("ranking"):
                    if event == "ranking:open":
                        this.client.ranking.open()
                    elif event == "ranking:close":
                        this.client.ranking.close2()
                ## End Ranking ##

                ## DeathMatch ##
                if textAreaID in [8983, 8984, 8985]:
                    if event.startswith("inventory"):
                        event = event.split("#")
                        if event[1] == "use":
                            this.client.deathStats[4] = int(event[2])
                        else:
                            this.client.deathStats[4] = 0
                        this.client.sendDeathInventory(this.client.page)

                if textAreaID == 123480 or textAreaID == 123479:
                    if event == "next":
                        if not this.client.page >= 3:
                            this.client.page += 1
                            this.client.sendDeathInventory(this.client.page)
                    else:
                        if not this.client.page <= 1:
                            this.client.page -= 1
                            this.client.sendDeathInventory(this.client.page)

                if textAreaID == 9012:
                    if event == "close":
                        ids = 131458, 123479, 130449, 131459, 123480, 6992, 8002, 23, 9012, 9013, 9893, 8983, 9014, 9894, 8984, 9015, 9895, 8985, 504, 505, 506, 507
                        for id in ids:
                            if id <= 507 and not id == 23:
                                this.client.sendPacket([29, 18], ByteArray().writeInt(id).toByteArray())
                            else:
                                this.client.sendPacket([29, 22], ByteArray().writeInt(id).toByteArray())

                if textAreaID == 9009:
                    if event == "close":
                        ids = 39, 40, 41, 7999, 20, 9009, 7239, 8249, 270
                        for id in ids:
                            if id <= 41 and not id == 20:
                                this.client.sendPacket([29, 18], ByteArray().writeInt(id).toByteArray())
                            else:
                                this.client.sendPacket([29, 22], ByteArray().writeInt(id).toByteArray())

                if textAreaID == 20:
                    if event.startswith("offset"):
                        event = event.split("#")
                        if event[1] == "offsetX":
                            if event[2] == "1":
                                if not this.client.deathStats[0] >= 25:
                                    this.client.deathStats[5] += 1
                                    this.client.deathStats[0] += 1
                            else:
                                if not this.client.deathStats[0] <= -25:
                                    this.client.deathStats[5] -= 1
                                    this.client.deathStats[0] -= 1
                        else:
                            if event[2] == "1":
                                if not this.client.deathStats[1] >= 25:
                                    this.client.deathStats[6] += 1
                                    this.client.deathStats[1] += 1
                            else:
                                if not this.client.deathStats[1] <= -25:
                                    this.client.deathStats[6] -= 1
                                    this.client.deathStats[1] -= 1
                    elif event == "show":
                        if this.client.deathStats[3] == 1:
                            this.client.deathStats[3] = 0
                        else:
                            this.client.deathStats[3] = 1
                    this.client.sendDeathProfile()
                return      
            
            elif CC == Identifiers.recv.Lua.Mouse_Click:
                posX, posY = packet.readShort(), packet.readShort()

                if this.client.isTeleport:
                    this.client.room.movePlayer(this.client.Username, posX, posY, False, 0, 0, False)

                elif this.client.isExplosion:
                    this.client.Utility.explosionPlayer(posX, posY)

            elif CC == Identifiers.recv.Lua.Key_Board:
                key, down, posX, posY = packet.readShort(), packet.readBool(), packet.readShort(), packet.readShort()

                if this.client.isFly and key == 32:
                    this.client.room.movePlayer(this.client.Username, 0, 0, True, 0, -50, True)

                if this.client.isSpeed and key == 32:
                    this.client.room.movePlayer(this.client.Username, 0, 0, True, 50 if this.client.isMovingRight else -50, 0, True)

                if this.client.room.isFFARace and key == 3 or key == 32:
                    if this.client.canSpawnCN:
                        if this.client.isMovingRight:
                            reactor.callLater(0.2, this.client.Utility.spawnObj, 17, posX - 10, posY +18, 90)
                        else:
                            reactor.callLater(0.2, this.client.Utility.spawnObj, 17, posX + 10, posY +18, -90)
                        reactor.callLater(2.5, this.client.Utility.removeObj)
                        this.client.canSpawnCN = False
                        reactor.callLater(1.3, this.client.enableSpawnCN)
                if this.client.room.isFFARace and key == 72:
                    this.client.config.close2()
                    this.client.room.addTextArea(150, "", this.client.Username, 160, 168, 480, 108, 3294800, 2570047, 100, False)
                    this.client.room.addTextArea(151, "", this.client.Username, 155, 150, 490, 13, 2570047, 2570047, 100, False)
                    this.client.room.addTextArea(152, "<V><b><font size=\'15\'>FFA Race Help</font></b>", this.client.Username, 155, 145, 465, 0, 0x000000, 0x000000, 100, False)
                    this.client.room.addTextArea(153, "", this.client.Username, 635, 152, 8, 8, 40349, 40349, 100, False)
                    this.client.room.addTextArea(154, "<p align=\'center\'><font size=\'14\' color=\'#324650\'><b><a href=\'event:ffarace:close\'>X", this.client.Username, 627, 146, 25, 25, 0x000000, 0x000000, 100, False)

                    # About
                    this.client.room.addTextArea(155, "", this.client.Username, 168, 252, 100, 13, 6590372, 6590372, 100, False)
                    this.client.room.addTextArea(156, "", this.client.Username, 172, 254, 100, 13, 1185564, 1185564, 100, False)
                    this.client.room.addTextArea(157, "", this.client.Username, 170, 253, 100, 13, 3952740, 3952740, 100, False)
                    this.client.room.addTextArea(158, "<p align=\'center\'><a href=\'event:ffarace:newHelp1\'>About", this.client.Username, 170, 251, 100, 0, 0x000000, 0x000000, 100, False)
                    this.client.room.addTextArea(159, "", this.client.Username, 170, 180, 100, 55, 3952740, 2570047, 100, False)

                    # How To Play
                    this.client.room.addTextArea(160, "", this.client.Username, 289, 252, 100, 13, 6590372, 6590372, 100, False)
                    this.client.room.addTextArea(161, "", this.client.Username, 291, 254, 100, 13, 1185564, 1185564, 100, False)
                    this.client.room.addTextArea(162, "", this.client.Username, 290, 253, 100, 13, 3952740, 3952740, 100, False)
                    this.client.room.addTextArea(163, "<p align=\'center\'><a href=\'event:ffarace:newHelp2\'>How To Play", this.client.Username, 290, 251, 100, 0, 0x000000, 0x000000, 100, False)
                    this.client.room.addTextArea(164, "", this.client.Username, 290, 180, 100, 55, 3952740, 2570047, 100, False)

                    # Commands
                    this.client.room.addTextArea(165, "", this.client.Username, 409, 252, 100, 13, 6590372, 6590372, 100, False)
                    this.client.room.addTextArea(166, "", this.client.Username, 411, 254, 100, 13, 1185564, 1185564, 100, False)
                    this.client.room.addTextArea(167, "", this.client.Username, 410, 253, 100, 13, 3952740, 3952740, 100, False)
                    this.client.room.addTextArea(168, "<p align=\'center\'><a href=\'event:ffarace:newHelp3\'>Commands", this.client.Username, 410, 251, 100, 0, 0x000000, 0x000000, 100, False)
                    this.client.room.addTextArea(169, "", this.client.Username, 410, 180, 100, 55, 3952740, 2570047, 100, False)

                    # Updates
                    this.client.room.addTextArea(170, "", this.client.Username, 529, 252, 100, 13, 6590372, 6590372, 100, False)
                    this.client.room.addTextArea(171, "", this.client.Username, 531, 254, 100, 13, 1185564, 1185564, 100, False)
                    this.client.room.addTextArea(172, "", this.client.Username, 530, 253, 100, 13, 3952740, 3952740, 100, False)
                    this.client.room.addTextArea(173, "<p align=\'center\'><a href=\'event:ffarace:newHelp4\'>Updates", this.client.Username, 530, 251, 100, 0, 0x000000, 0x000000, 100, False)
                    this.client.room.addTextArea(174, "", this.client.Username, 530, 180, 100, 55, 3952740, 2570047, 100, False)

                    this.client.sendPacket([29, 19], "\x00\x00\x00\x01\x00\x0b2e0YbYf.png\x07\x00\x00\x00\x01\x00\xa0\x00\xb1")

                if this.client.room.isDeathmatch and key == 3 or key == 32:
                    if this.client.room.canCannon:
                        if not this.client.canCN:
                            this.client.room.objectID += 1
                            idCannon = {15: "149aeaa271c.png", 16: "149af112d8f.png", 17: "149af12c2d6.png", 18: "149af130a30.png", 19: "149af0fdbf7.png", 20: "149af0ef041.png", 21: "149af13e210.png", 22: "149af129a4c.png", 23: "149aeaa06d1.png"}
                            #idCannon = "149aeaa271c.png" if this.client.deathStats[4] == 15 else "149af112d8f.png" if this.client.deathStats[4] == 16 else "149af12c2d6.png"
                            if this.client.isMovingRight:
                                x = int(this.client.posX+this.client.deathStats[0]) if this.client.deathStats[0] < 0 else int(this.client.posX+this.client.deathStats[0])
                                y = int(this.client.posY+this.client.deathStats[1]) if this.client.deathStats[1] < 0 else int(this.client.posY+this.client.deathStats[1])
                                this.client.sendPlaceObject(this.client.room.objectID, 17, x, y, 90, 0, 0, True, True)
                                if this.client.deathStats[4] in [15, 16, 17, 18, 19, 20, 21, 22, 23]:
                                    if not this.client.deathStats[3] == 1:
                                        this.client.room.sendAll([29, 19], ByteArray().writeInt(this.client.playerCode).writeUTF(idCannon[this.client.deathStats[4]]).writeByte(1).writeInt(this.client.room.objectID).toByteArray()+"\xff\xf0\xff\xf0")
                            else:
                                x = int(this.client.posX-this.client.deathStats[0]) if this.client.deathStats[0] < 0 else int(this.client.posX-this.client.deathStats[0])
                                y = int(this.client.posY+this.client.deathStats[1]) if this.client.deathStats[1] < 0 else int(this.client.posY+this.client.deathStats[1])
                                this.client.sendPlaceObject(this.client.room.objectID, 17, x, y, -90, 0, 0, True, True)
                                if this.client.deathStats[4] in [15, 16, 17, 18, 19, 20, 21, 22, 23]:
                                    if not this.client.deathStats[3] == 1:
                                        this.client.room.sendAll([29, 19], ByteArray().writeInt(this.client.playerCode).writeUTF(idCannon[this.client.deathStats[4]]).writeByte(1).writeInt(this.client.room.objectID).toByteArray()+"\xff\xf0\xff\xf0")
                            this.client.canCN = True       
                            this.canCCN = reactor.callLater(0.8, this.client.cnTrueOrFalse)
                if this.client.room.isDeathmatch and key == 79:
                    this.client.sendDeathInventory()
                if this.client.room.isDeathmatch and key == 80:
                    this.client.sendDeathProfile()

                if this.client.room.isInvocation and key == 32:
                    if this.client.invocationPoints >= 1:
                        this.client.room.objectID += 1
                        item = [28, 1, 2, 29, 30, 31, 32, 33, 34, 35, 3, 4]
                        id = random.choice(item)
                        this.client.sendPlaceObject(this.client.room.objectID, id, posX+4, posY+16, 90, 0, 0, True, True)
                        this.client.invocationPoints -= 1
                        this.client.sendLangueMessage("", "<ROSE>[#INVOCATION#] - <N>Você tem: <J>"+str(this.client.invocationPoints)+"</J> items.")
                    else:
                        this.client.sendLangueMessage("", "<ROSE>[#INVOCATION#] - <J>0<N> items, espere a próxima partida para usar novamente.")

                if this.client.room.isExplosion and key == 32:
                    if this.client.explosionPoints >= 1:
                        this.client.room.objectID += 1
                        this.client.sendPlaceObject(this.client.room.objectID, 24, posX-12 if this.client.isMovingRight else posX+12, posY+18, 90, 0, 0, True, True)
                        this.client.explosionPoints -= 1
                        this.client.sendLangueMessage("", "<ROSE>[#EXPLOSION#] - <N>Você tem: <J>"+str(this.client.explosionPoints)+"</J> explosões.")
                    else:
                        this.client.sendLangueMessage("", "<ROSE>[#EXPLOSION#] - <J>0<N> explosões, espere a próxima partida para usar novamente.")

                if this.client.room.isBallonRace and key == 32:
                    if this.client.ballonracePoints >= 1:
                        this.client.room.objectID += 1
                        this.client.sendPlaceObject(this.client.room.objectID, 28, posX-2, posY+25, 90, 0, 0, True, True)
                        this.client.ballonracePoints -= 1
                        this.client.sendLangueMessage("", "<ROSE>[#BALLON-RACE#] - <N>Você tem: <J>"+str(this.client.ballonracePoints)+"</J> balões.")
                    else:
                        this.client.sendLangueMessage("", "<ROSE>[#BALLON-RACE#] - <J>0<N> balões, espere a próxima partida para usar novamente.")

                if this.client.room.isFly and key == 32:
                    if this.client.flyPoints >= 1:
                        this.client.room.movePlayer(this.client.Username, 0, 0, True, 0, -50, True)
                        this.client.flyPoints -= 1
                        this.client.sendLangueMessage("", "<ROSE>[#FLY#] - <N>Você tem: <J>"+str(this.client.flyPoints)+"</J> voos.")
                    else:
                        this.client.sendLangueMessage("", "<ROSE>[#FLY#] - <J>0<N> voos, espere a próxima partida para usar novamente.")

                if this.client.room.isPokeLua and key == 39 or key == 65:
                    this.client.PokeLua.removeImage(1)
                    try:
                        reactor.callLater(0.3, lambda: this.client.PokeLua.addImage(0, this.client.PokeLua.pokeSelect[1], 3, this.client.playerCode, -45, -52, ""))
                    except:
                        pass
                if this.client.room.isPokeLua and key == 37 or key == 68:
                    this.client.PokeLua.removeImage(0)
                    try:
                        reactor.callLater(0.3, lambda: this.client.PokeLua.addImage(1, this.client.PokeLua.pokeSelect[0], 3, this.client.playerCode, -45, -52, ""))
                    except:
                        pass

                if tihs.client.room.isPropHunt and key == 69:
                    pass
                if tihs.client.room.isPropHunt and key == 32:
                    pass
                return

            elif CC == Identifiers.recv.Lua.Color_Picked:
                colorPickerId, color = packet.readInt(), packet.readInt()

                if colorPickerId == 10000:
                    if color != -1:
                        this.client.nameColorMap = "%06X" %(0xFFFFFF & color)
                        this.client.room.setNameColor(this.client.Username, color)
                        this.client.sendMessage("A cor do nome do seu rato no mapa foi alterada.")
                elif colorPickerId == 10001:
                    if color != -1:
                        this.client.MouseColor = "%06X" %(0xFFFFFF & color)
                        this.client.playerLook = "1;" + this.client.playerLook.split(";")[1]
                        this.client.sendMessage("A cor do seu rato foi alterada.")
                elif colorPickerId == 10002:
                    if color != -1:
                        this.client.nameColorChat = "%06X" %(0xFFFFFF & color)
                        this.client.sendMessage("A cor do nome do seu rato no chat foi alterada.")
                        this.client.updateDatabase()
                return

        elif C == Identifiers.recv.Informations.C:
            if CC == Identifiers.recv.Informations.Game_Log:
                errorC, errorCC, oldC, oldCC, error = packet.readByte(), packet.readByte(), packet.readUnsignedByte(), packet.readUnsignedByte(), packet.readUTF()
                if this.server.DEBUG:
                    if errorC == 1 and errorCC == 1:
                        this.server.sendOutput("["+this.client.Username+"] [Old] GameLog Error: C: "+str(oldC)+" CC: "+str(oldCC)+" error: "+str(error))
                    elif errorC == 60 and errorCC == 3:
                        if oldC == Identifiers.tribulle.send.ET_SignaleDepartMembre or oldC == Identifiers.tribulle.send.ET_SignaleExclusion: return
                        this.server.sendOutput("["+this.client.Username+"] [TRIBULLE] GameLog Error: Code: "+str(oldC)+" error: "+str(error))
                    else:
                        if errorC == Identifiers.send.Add_Frame[0] and errorCC == Identifiers.send.Add_Frame[1]: return
                        this.server.sendOutput("["+this.client.Username+"] GameLog Error: C: "+str(errorC)+" CC: "+str(errorCC)+" error: "+str(error))
                return

            elif CC == Identifiers.recv.Informations.Change_Shaman_Type:
                type = packet.readByte()
                this.client.shamanType = type
                this.client.sendShamanType(type, (this.client.shamanSaves >= 2500 and this.client.hardModeSaves >= 1000))
                return

            elif CC == Identifiers.recv.Informations.Letter:
                try:
                    playerName, type = this.client.TFMUtils.parsePlayerName(packet.readUTF()), packet.readByte()
                    letter = packet
                    
                    if this.server.checkExistingUser(playerName):
                        id = 29 if type == 0 else 30 if type == 1 else 2241
                        count = this.client.playerConsumables[id] - 1
                        if count <= 0:
                            del this.client.playerConsumables[id]
                            if id in this.client.equipedConsumables:
                                this.client.equipedConsumables.remove(id)
                        else:
                            this.client.playerConsumables[id] = count

                        this.client.updateInventoryConsumable(id, count)
                        this.client.useInventoryConsumable(id)
                        
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.sendPacket(Identifiers.send.Letter, ByteArray().writeUTF(this.client.Username).writeUTF(str(int(this.client.MouseColor, 16)) + "##" + str(this.client.playerLook)).writeByte(type).writeBytes(letter).toByteArray())
                        else:
                            letters = ""
                            this.Cursor.execute("select Letters from users where Username = ?", [playerName])
                            rs = this.Cursor.fetchone()
                            letters = rs["Letters"]

                            letters += ("" if letters == "" else "/") + "|".join(map(str, [this.client.Username, str(int(this.client.MouseColor, 16)) + "##" + str(this.client.playerLook), type, binascii.hexlify(letter)]))
                            this.Cursor.execute("update users set Letters = ? where Username = ?", [letters, playerName])
                        
                        this.client.sendLangueMessage("", "$MessageEnvoye")
                    else:
                        this.client.sendLangueMessage("", "$Joueur_Existe_Pas")
                except:
                    pass
                return

            elif CC == Identifiers.recv.Informations.Send_Gift:
                this.client.sendPacket(Identifiers.send.Send_Gift, chr(1))
                return

            elif CC == Identifiers.recv.Informations.Computer_Info:
                this.client.realLangue = packet.readUTF().upper()
                this.client.canLogin[0] = True

                if this.client.realLangue == "PT":
                    this.client.realLangue = "BR"
                return

            elif CC == Identifiers.recv.Informations.Change_Shaman_Color:
                color = packet.readInt()
                this.client.ShamanColor = "%06X" %(0xFFFFFF & color)
                return

            elif CC == Identifiers.recv.Informations.Informations:
                this.client.sendPacket(Identifiers.send.Tribulle_Token, ByteArray().writeUTF(this.client.apiToken).toByteArray())
                return

            elif CC == Identifiers.recv.Informations.Request_Info:
                this.client.sendPacket(Identifiers.send.Request_Info, ByteArray().writeUTF("http://195.154.124.74/outils/info.php").toByteArray())
                return

        elif C == Identifiers.recv.Cafe.C:
            if CC == Identifiers.recv.Cafe.Mulodrome_Close:
                this.client.room.sendAll(Identifiers.send.Mulodrome_End, "")
                return

            elif CC == Identifiers.recv.Cafe.Mulodrome_Join:
                team, position = packet.readByte(), packet.readByte()

                if len(this.client.mulodromePos) != 0:
                    this.client.room.sendAll(Identifiers.send.Mulodrome_Leave, chr(this.client.mulodromePos[0]) + chr(this.client.mulodromePos[1]))

                this.client.mulodromePos = [team, position]
                this.client.room.sendAll(Identifiers.send.Mulodrome_Join, ByteArray().writeByte(team).writeByte(position).writeInt(this.client.playerID).writeUTF(this.client.Username).writeUTF(this.client.tribeName).toByteArray())
                if this.client.Username in this.client.room.redTeam: this.client.room.redTeam.remove(this.client.Username)
                if this.client.Username in this.client.room.blueTeam: this.client.room.blueTeam.remove(this.client.Username)
                if team == 1:
                    this.client.room.redTeam.append(this.client.Username)
                else:
                    this.client.room.blueTeam.append(this.client.Username)
                return

            elif CC == Identifiers.recv.Cafe.Mulodrome_Leave:
                team, position = packet.readByte(), packet.readByte()
                this.client.room.sendAll(Identifiers.send.Mulodrome_Leave, ByteArray().writeByte(team).writeByte(position).toByteArray())
                if team == 1:
                    for username in this.client.room.redTeam:
                        if this.client.room.clients[username].mulodromePos[1] == position:
                            this.client.room.redTeam.remove(username)
                            break
                else:
                    for username in this.client.room.blueTeam:
                        if this.client.room.clients[username].mulodromePos[1] == position:
                            this.client.room.blueTeam.remove(username)
                            break
                return

            elif CC == Identifiers.recv.Cafe.Mulodrome_Play:
                if not len(this.client.room.redTeam) == 0 or not len(this.client.room.blueTeam) == 0:
                    this.client.room.isMulodrome = True
                    this.client.room.isRacing = True
                    this.client.room.noShaman = True
                    this.client.room.mulodromeRoundCount = 0
                    this.client.room.never20secTimer = True
                    this.client.room.sendAll(Identifiers.send.Mulodrome_End, "")
                    this.client.room.mapChange()
                return

            elif CC == Identifiers.recv.Cafe.Reload_Cafe:
                this.client.loadCafeMode()
                return

            elif CC == Identifiers.recv.Cafe.Open_Cafe_Topic:
                topicID = packet.readInt()
                this.client.openCafeTopic(topicID)
                return

            elif CC == Identifiers.recv.Cafe.Create_New_Cafe_Topic:
                message , title = packet.readUTF(), packet.readUTF()
                if this.client.privLevel >= 5 or (this.client.Langue.upper() == this.client.realLangue and this.client.privLevel != 0 and this.client.cheeseCount >= 100):
                    this.client.createNewCafeTopic(message, title)
                return

            elif CC == Identifiers.recv.Cafe.Create_New_Cafe_Post:
                topicID, message = packet.readInt(), packet.readUTF()
                if this.client.privLevel >= 5 or (this.client.Langue.upper() == this.client.realLangue and this.client.privLevel != 0 and this.client.cheeseCount >= 100):
                    this.client.createNewCafePost(topicID, message)
                return

            elif CC == Identifiers.recv.Cafe.Open_Cafe:
                this.client.isCafe = packet.readBool()
                return

            elif CC == Identifiers.recv.Cafe.Vote_Cafe_Post:
                topicID, postID, mode = packet.readInt(), packet.readInt(), packet.readBool()
                if this.client.privLevel >= 5 or (this.client.Langue.upper() == this.client.realLangue and this.client.privLevel != 0 and this.client.cheeseCount >= 100):
                    this.client.voteCafePost(topicID, postID, mode)
                return

            elif CC == Identifiers.recv.Cafe.Delete_Cafe_Message:
                if this.client.privLevel >= 7:
                    topicID, postID = packet.readInt(), packet.readInt()
                    this.client.deleteCafePost(topicID, postID)
                else:
                	this.client.sendMessage("Você não está autorizado a usar esta função.")
                return

            elif CC == Identifiers.recv.Cafe.Delete_All_Cafe_Message:
                if this.client.privLevel >= 7:
                    topicID, playerName = packet.readInt(), packet.readUTF()
                    this.client.deleteAllCafePost(topicID, playerName)
                else:
                	this.client.sendMessage("Você não está autorizado a usar esta função.")
                return

        elif C == Identifiers.recv.Inventory.C:
            if CC == Identifiers.recv.Inventory.Open_Inventory:
                this.client.sendInventoryConsumables()
                return

            elif CC == Identifiers.recv.Inventory.Use_Consumable:
                id = packet.readShort()
                if this.client.playerConsumables.has_key(id) and not this.client.isDead and not this.client.room.isRacing and not this.client.room.isBootcamp and not this.client.room.isSurvivor and not this.client.room.isDefilante:
                    if not this.client.canUseConsumable:
                        this.client.sendMessage("Wait 1 second to use consumables again.")
                    elif not id in [31, 34 , 2240, 2247, 2262] or this.client.pet == 0:
                        this.client.canUseConsumable = False
                        this.client.consumablesTimer = reactor.callLater(1, setattr, this.client, "canUseConsumable", True)
                        try:
                            if count <= 0:
                                del this.client.playerConsumables[id]
                                this.client.equipedConsumables.remove(str(id))
                            else:
                                this.client.playerConsumables[id] -= 1
                        except:
                            pass

                        if id == 2100:
                            ids = random.randint(0, 2383)
                            if not ids in this.client.playerConsumables or not ids == 0:
                                this.client.playerConsumables[ids] = 1
                            elif ids == 0:
                                q = random.randint(1, 15000)
                                f = random.randint(1, 15000)
                                this.client.cheeseCount += q
                                this.client.firstCount += f
                            elif ids == 2382:
                                this.client.aventureCounts[2382] += 1
                            else:
                                count = this.client.playerConsumables[ids] + 1
                                this.client.playerConsumables[ids] = count
                            this.client.sendAnimZeldaInventory(4, ids, 1)

                        if id == 1 or id == 5 or id == 6 or id == 8 or id == 11 or id == 20 or id == 24 or id == 25 or id == 26:
                            if id == 11:
                                this.client.room.objectID += 2
                            #this.client.sendPlaceObject(this.client.room.objectID if id == 11 else 0, 65 if id == 1 else 6 if id == 5 else 34 if id == 6 else 89 if id == 8 else 90 if id == 11 else 33 if id == 20 else 63 if id == 24 else 80 if id == 25 else 95 if id == 26 else 0, this.client.posX + 28 if this.client.isMovingRight else this.client.posX - 28, this.client.posY, 0, 0 if id == 11 or id == 24 else 10 if this.client.isMovingRight else -10, -3, True, True)
                            this.client.sendPlaceObject(this.client.room.objectID if id == 11 else 0, 65 if id == 1 else 6 if id == 5 else 34 if id == 6 else 89 if id == 8 else 90 if id == 11 else 33 if id == 20 else 63 if id == 24 else 80 if id == 25 else 95 if id == 26 else 0, this.client.posX + 28 if this.client.isMovingRight else this.client.posX - 28, this.client.posY, 0, 0 if id == 11 or id == 24 else 10 if this.client.isMovingRight else -10, -3, True, True)

                        if id == 2239:
                            this.client.firstCount += random.randint(1, 1000)
                            this.client.cheeseCount += random.randint(1, 1000)
                        
                        if id == 28:
                            this.client.skillModule.sendBonfireSkill(this.client.posX, this.client.posY, 15)

                        if id in [31, 34 , 2240, 2247, 2262]:
                            this.client.pet = 2 if id == 31 else 3 if id == 34 else 4 if id == 2240 else 5 if id == 2247 else 6
                            this.client.petEnd = this.client.TFMUtils.getTime() + 3600
                            this.client.room.sendAll(Identifiers.send.Pet, ByteArray().writeInt(this.client.playerCode).writeUnsignedByte(this.client.pet).toByteArray())

                        if id == 33:
                            this.client.sendPlayerEmote(16, "", False, False)

                        if id == 35:
                            if len(this.client.shamanBadges) > 0:
                                this.client.room.sendAll(Identifiers.send.Balloon_Badge, ByteArray().writeInt(this.client.playerCode).writeUnsignedByte(random.randint(0, len(this.client.shopBadges))).toByteArray())

                        if id == 2234:
                            x = 0
                            this.client.sendPlayerEmote(20, "", False, False)
                            for player in this.client.room.clients.values():
                                if x < 5 and player != this.client:
                                    if player.posX >= this.client.posX - 400 and player.posX <= this.client.posX + 400:
                                        if player.posY >= this.client.posY - 300 and player.posY <= this.client.posY + 300:
                                            player.sendPlayerEmote(6, "", False, False)
                                            x += 1
                        
                        if id == 2239:
                            this.client.room.sendAll(Identifiers.send.Crazzy_Packet, ByteArray().writeUnsignedByte(3).writeInt(this.client.playerCode).writeInt(this.client.shopCheeses).toByteArray())

                        if id == 2246:
                            this.client.sendPlayerEmote(24, "", False, False)

                        if id == 2252:
                            if not this.client.isShaman:
                                this.client.sendPacket(Identifiers.send.Crazzy_Packet, ByteArray().writeUnsignedByte(1).writeUnsignedShort(650).writeInt(0).toByteArray())

                        this.client.updateInventoryConsumable(id, count)
                        this.client.useInventoryConsumable(id)
                return

            elif CC == Identifiers.recv.Inventory.Equip_Consumable:
                id, equip = packet.readShort(), packet.readBool()
                try:
                    if equip:
                        this.client.equipedConsumables.append(id)
                    else:
                        this.client.equipedConsumables.remove(str(id))
                except: pass
                return
                
            elif CC == Identifiers.recv.Inventory.Trade_Invite:
                playerName = packet.readUTF()
                this.client.tradeInvite(playerName)
                return
                
            elif CC == Identifiers.recv.Inventory.Cancel_Trade:
                playerName = packet.readUTF()
                this.client.cancelTrade(playerName)
                return
                
            elif CC == Identifiers.recv.Inventory.Trade_Add_Consusmable:
                id, isAdd = packet.readShort(), packet.readBool()
                if id == 2100:
                    id = 2102
                try:
                    this.client.tradeAddConsumable(id, isAdd)
                except: pass
                return
                
            elif CC == Identifiers.recv.Inventory.Trade_Result:
                isAccept = packet.readBool()
                this.client.tradeResult(isAccept)
                return

        elif C == Identifiers.recv.Tribulle.C:
            if CC == Identifiers.recv.Tribulle.Tribulle:
                if not this.client.isGuest:
                    code = packet.readShort()
                    #print("Tribulle Code: ["+str(code)+"] Tribulle Packet: ["+repr(packet.toByteArray())+"]")
                    this.client.tribulle.parseTribulleCode(code, packet)
                return

        elif C == Identifiers.recv.Transformice.C:
            if CC == Identifiers.recv.Transformice.Invocation:
                objectCode, posX, posY, rotation, position, invocation = packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readUTF(), packet.readBool()
                this.client.room.sendAllOthers(this.client, Identifiers.send.Invocation, ByteArray().writeInt(this.client.playerCode).writeShort(objectCode).writeShort(posX).writeShort(posY).writeShort(rotation).writeUTF(position).writeBool(invocation).toByteArray())
                return

            elif CC == Identifiers.recv.Transformice.Remove_Invocation:
                this.client.room.sendAllOthers(this.client, Identifiers.send.Remove_Invocation, ByteArray().writeInt(this.client.playerCode).toByteArray())
                return

            elif CC == Identifiers.recv.Transformice.Change_Shaman_Badge:
                badge = packet.readByte()
                if str(badge) or badge == 0 in this.client.shamanBadges:
                    this.client.equipedShamanBadge = str(badge)
                    this.client.sendProfile(this.client.Username)
                return

            elif CC == Identifiers.recv.Transformice.Map_Info:
                this.client.room.cheesesList = []
                cheesesCount = packet.readByte()
                i = 0
                while i < cheesesCount / 2:
                    cheeseX, cheeseY = packet.readShort(), packet.readShort()
                    this.client.room.cheesesList.append([cheeseX, cheeseY])
                    i += 1
                
                this.client.room.holesList = []
                holesCount = packet.readByte()
                i = 0
                while i < holesCount / 3:
                    holeType, holeX, holeY = packet.readShort(), packet.readShort(), packet.readShort()
                    this.client.room.holesList.append([holeType, holeX, holeY])
                    i += 1
                return

            elif CC == Identifiers.recv.Transformice.Bots_Village:
                packet = packet.toByteArray()
                p = ByteArray(packet)
                if packet[3:] == "Papaille" or packet[3:] == "Elise" or packet[3:] == "Von Drekkemouse" or packet[3:] == "Cassidy" or packet[3:] == "Oracle" or packet[3:] == "Prof" or packet[3:] == "Buffy" or packet[3:] == "Indiana Mouse" or packet[3:] == "Tod" or packet[3:] == "Noel":
                    id, bot = p.readByte(), p.readUTF()
                    this.client.botVillage = bot
                    this.client.BotsVillage(bot)
                else:
                    id, linha = p.readByte(), p.readByte()
                    coisa = this.client.itensBots[this.client.botVillage][linha]
                    this.client.premioVillage(coisa)
                        
                this.client.room.sendAll([100, 40], ByteArray().writeByte(2).writeInt(this.client.playerCode).toByteArray() + "\x00\xc9>" + packet)

            elif CC == Identifiers.recv.Transformice.Done_Visual:
                p = ByteArray(packet.toByteArray())
                visuID = p.readShort()

                #this.client.sendMessage("Caso haja algúm bug no Fashion Squad contate um Administrador.")
                shopItems = [] if this.client.shopItems == "" else this.client.shopItems.split(",")
                look = this.server.newVisuList[visuID].split(";")
                look[0] = int(look[0])
                lengthCloth = len(this.client.clothes)
                buyCloth = 5 if (lengthCloth == 0) else (50 if lengthCloth == 1 else 100)

                this.client.visuItems = {-1: {"ID": -1, "Buy": buyCloth, "Bonus": True, "Customizable": False, "HasCustom": False, "CustomBuy": 0, "Custom": "", "CustomBonus": False}, 22: {"ID": this.client.getFullItemID(22, look[0]), "Buy": this.client.getItemInfo(22, look[0])[6], "Bonus": False, "Customizable": False, "HasCustom": False, "CustomBuy": 0, "Custom": "", "CustomBonus": False}}

                count = 0
                for visual in look[1].split(","):
                    if not visual == "0":
                        item, customID = visual.split("_", 1) if "_" in visual else [visual, ""]
                        print item, customID
                        item = int(item)
                        itemID = this.client.getFullItemID(count, item)
                        itemInfo = this.client.getItemInfo(count, item)
                        this.client.visuItems[count] = {"ID": itemID, "Buy": itemInfo[6], "Bonus": False, "Customizable": bool(itemInfo[2]), "HasCustom": customID != "", "CustomBuy": itemInfo[7], "Custom": customID, "CustomBonus": False}
                        if this.client.shopModule.checkInShop(this.client.visuItems[count]["ID"]):
                            this.client.visuItems[count]["Buy"] -= itemInfo[6]
                        if itemID in this.client.custom:
                            this.client.visuItems[count]["HasCustom"] = True
                        else:
                            this.client.visuItems[count]["HasCustom"] = False
                    count += 1

                hasVisu = map(lambda y: 0 if y in shopItems else 1, map(lambda x: x["ID"], this.client.visuItems.values()))
                visuLength = reduce(lambda x, y: x + y, hasVisu)
                print hasVisu, visuLength
                
                allPriceBefore = 0
                allPriceAfter = 0
                promotion = 70.0 / 100

                p.writeUnsignedShort(visuID)
                p.writeUnsignedByte(20)
                p.writeUTF(this.server.newVisuList[visuID])
                p.writeUnsignedByte(visuLength)

                for category in this.client.visuItems.keys():
                    if len(this.client.visuItems.keys()) == category:
                        category = 22
                    itemID = this.client.getSimpleItemID(category, this.client.visuItems[category]["ID"])

                    buy = [this.client.visuItems[category]["Buy"], int(this.client.visuItems[category]["Buy"] * promotion)]
                    customBuy = [this.client.visuItems[category]["CustomBuy"], int(this.client.visuItems[category]["CustomBuy"] * promotion)]

                    p.writeShort(this.client.visuItems[category]["ID"])
                    p.writeUnsignedByte(2 if this.client.visuItems[category]["Bonus"] else (1 if not this.client.shopModule.checkInShop(this.client.visuItems[category]["ID"]) else 0))
                    p.writeUnsignedShort(buy[0])
                    p.writeUnsignedShort(buy[1])
                    p.writeUnsignedByte(3 if not this.client.visuItems[category]["Customizable"] else (2 if this.client.visuItems[category]["CustomBonus"] else (1 if this.client.visuItems[category]["HasCustom"] == False else 0)))
                    p.writeUnsignedShort(customBuy[0])
                    p.writeUnsignedShort(customBuy[1])
                    
                    allPriceBefore += buy[0] + customBuy[0]
                    allPriceAfter += (0 if (this.client.visuItems[category]["Bonus"]) else (0 if this.client.shopModule.checkInShop(itemID) else buy[1])) + (0 if (not this.client.visuItems[category]["Customizable"]) else (0 if this.client.visuItems[category]["CustomBonus"] else (0 if this.client.visuItems[category]["HasCustom"] else (customBuy[1]))))

                p.writeShort(allPriceBefore)
                p.writeShort(allPriceAfter)
                this.client.priceDoneVisu = allPriceAfter

                this.client.sendPacket([100, 31], p.toByteArray())

            elif CC == Identifiers.recv.Transformice.Paint_Consumable:
                return

        if this.server.DEBUG:
            print "[%s] Not implemented Packet: C: %s - CC: %s - packet: %s" %(this.client.Username, C, CC, str(repr(packet.toByteArray())))

    def parsePacketUTF(this, packet):
        values = packet.split(str(chr(1)))
        C = ord(values[0][0])
        CC = ord(values[0][1])
        values = values[1:]

        if C == Identifiers.old.recv.Player.C:
            if CC == Identifiers.old.recv.Player.Conjure_Start:
                this.client.room.sendAll(Identifiers.old.send.Conjure_Start, values)
                return

            elif CC == Identifiers.old.recv.Player.Conjure_End:
                this.client.room.sendAll(Identifiers.old.send.Conjure_End, values)
                return

            elif CC == Identifiers.old.recv.Player.Conjuration:
                reactor.callLater(10, this.client.sendConjurationDestroy, int(values[0]), int(values[1]))
                this.client.room.sendAll(Identifiers.old.send.Add_Conjuration, values)
                return

            elif CC == Identifiers.old.recv.Player.Snow_Ball:
                this.client.sendPlaceObject(0, 34, int(values[0]), int(values[1]), 0, 0, 0, False, True)
                return

            elif CC == Identifiers.old.recv.Player.Bomb_Explode:
                this.client.room.sendAll(Identifiers.old.send.Bomb_Explode, values)
                return

        elif C == Identifiers.old.recv.Room.C:
            if CC == Identifiers.old.recv.Room.Anchors:
                this.client.room.sendAll(Identifiers.old.send.Anchors, values)
                this.client.room.anchors.extend(values)
                return

            elif CC == Identifiers.old.recv.Room.Begin_Spawn:
                if not this.client.isDead:
                    this.client.room.sendAll(Identifiers.old.send.Begin_Spawn, [this.client.playerCode] + values)
                return

            elif CC == Identifiers.old.recv.Room.Spawn_Cancel:
                this.client.room.sendAll(Identifiers.old.send.Spawn_Cancel, [this.client.playerCode])
                return

            elif CC == Identifiers.old.recv.Room.Totem_Anchors:
                code, x, y = values[0], values[1], values[2]

                if this.client.room.isTotemEditeur:
                    if this.client.room.tempTotemCount < 20:
                        this.client.room.tempTotemCount += 1
                        this.client.sendTotemItemCount(this.client.room.tempTotemCount)
                        this.client.Totem[0] = this.client.room.tempTotemCount
                        this.client.Totem[1] += "#3#" + chr(1).join(map(str, [code + x + y]))
                return

            elif CC == Identifiers.old.recv.Room.Move_Cheese:
                this.client.room.sendAll(Identifiers.old.send.Move_Cheese, values)
                return

            elif CC == Identifiers.old.recv.Room.Bombs:
                this.client.room.sendAll(Identifiers.old.send.Bombs, values)
                return

        elif C == Identifiers.old.recv.Balloons.C:
            if CC == Identifiers.old.recv.Balloons.Place_Balloon:
                this.client.room.sendAll(Identifiers.old.send.Balloon, values)
                return

            elif CC == Identifiers.old.recv.Balloons.Remove_Balloon:
                this.client.room.sendAllOthers(this.client, Identifiers.old.send.Balloon, [this.client.playerCode, "0"])
                return

        elif C == Identifiers.old.recv.Map.C:
            if CC == Identifiers.old.recv.Map.Vote_Map:
                if len(values) == 0:
                    this.client.room.receivedNo += 1
                else:
                    this.client.room.receivedYes += 1
                return

            elif CC == Identifiers.old.recv.Map.Load_Map:
                values[0] = values[0].replace("@", "")
                if values[0].isdigit():
                    code = int(values[0])
                    this.Cursor.execute("select * from mapeditor where Code = ?", [code])
                    rs = this.Cursor.fetchone()
                    if rs:
                        if this.client.Username == rs["Name"] or this.client.privLevel >= 6:
                            this.client.sendPacket(Identifiers.old.send.Load_Map, [rs["XML"], rs["YesVotes"], rs["NoVotes"], rs["Perma"]])
                            this.client.room.EMapXML = rs["XML"]
                            this.client.room.EMapLoaded = code
                            this.client.room.EMapValidated = False
                        else:
                            this.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                    else:
                        this.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                else:
                    this.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                return

            elif CC == Identifiers.old.recv.Map.Validate_Map:
                mapXML = values[0]
                if this.client.TFMUtils.checkValidXML(mapXML):
                    this.client.sendPacket(Identifiers.old.send.Map_Editor, [""])
                    this.client.room.EMapValidated = False
                    this.client.room.EMapCode = 1
                    this.client.room.EMapXML = mapXML
                    this.client.room.mapChange()
                return

            elif CC == Identifiers.old.recv.Map.Map_Xml:
                this.client.room.EMapXML = values[0]
                return

            elif CC == Identifiers.old.recv.Map.Return_To_Editor:
                this.client.room.EMapCode = 0
                this.client.sendPacket(Identifiers.old.send.Map_Editor, ["", ""])
                return

            elif CC == Identifiers.old.recv.Map.Export_Map:
                isTribeHouse = len(values) != 0
                if this.client.cheeseCount < 50 and this.client.privLevel < 6 and not isTribeHouse:
                    this.client.sendPacket(Identifiers.old.send.Editor_Message, [""])
                elif this.client.shopCheeses < (5 if isTribeHouse else 40) and this.client.privLevel < 6:
                    this.client.sendPacket(Identifiers.old.send.Editor_Message, ["", ""])
                elif this.client.room.EMapValidated or isTribeHouse:
                    if this.client.privLevel < 6:
                        this.client.shopCheeses -= 5 if isTribeHouse else 40

                    code = 0
                    if this.client.room.EMapLoaded != 0:
                        code = this.client.room.EMapLoaded
                        this.Cursor.execute("update mapeditor set XML = ?, Updated = ? where Code = ?", [this.client.room.EMapXML, this.client.TFMUtils.getTime(), code])
                    else:
                        this.server.lastMapEditeurCode += 1
                        code = this.server.lastMapEditeurCode
                        this.Cursor.execute("insert into mapeditor values (?, ?, ?, 0, 0, ?, ?, '', '')", [code, this.client.Username, this.client.room.EMapXML, 22 if isTribeHouse else 0, this.client.TFMUtils.getTime()])
                        this.server.updateConfig()

                    this.client.sendPacket(Identifiers.old.send.Map_Editor, ["0"])
                    this.client.enterRoom(this.server.recommendRoom(this.client.Langue))
                    this.client.sendPacket(Identifiers.old.send.Map_Exported, [code])
                return

            elif CC == Identifiers.old.recv.Map.Reset_Map:
                this.client.room.EMapLoaded = 0
                return

            elif CC == Identifiers.old.recv.Map.Exit_Editor:
                this.client.sendPacket(Identifiers.old.send.Map_Editor, ["0"])
                this.client.enterRoom(this.server.recommendRoom(this.client.Langue))
                return

        elif C == Identifiers.old.recv.Draw.C:
            if CC == Identifiers.old.recv.Draw.Drawing:
                if this.client.privLevel >= 10:
                    this.client.room.sendAllOthers(this.client, Identifiers.old.send.Drawing, values)
                return

            elif CC == Identifiers.old.recv.Draw.Point:
                if this.client.privLevel >= 10:
                    this.client.room.sendAllOthers(this.client, Identifiers.old.send.Drawing_Point, values)
                return

            elif CC == Identifiers.old.recv.Draw.Clear:
                if this.client.privLevel >= 10:
                    this.client.room.sendAll(Identifiers.old.send.Drawing_Clear, values)
                return

        elif C == Identifiers.old.recv.Dummy.C:
            if CC == Identifiers.old.recv.Dummy.Dummy:
                this.client.isReceivedDummy = True
                return

        if this.server.DEBUG:
            print "[%s][OLD] Not implemented Packet: C: %s - CC: %s - values: %s" %(this.client.playerName, C, CC, str(repr(values.toByteArray())))
