# -*- coding: utf-8 -*-
import re, struct, random, time

# Modules
from ByteArray import ByteArray

class Utility:
    def __init__(this, client, server):
        this.client = client
        this.isCommand = False
        this.lastObjID = 0
        this.canExplosion = False
        this.isFireworks = False
        this.conjX = 0
        this.conjY = 0

    def spawnObj(this, objID, posX, posY, angle):
        itemID = random.randint(100, 999)
        objID = int(objID)
        posX = int(posX)
        posY = int(posY)
        data = struct.pack("!ihhhhhbb", itemID, objID, posX, posY, angle, 0, 1, 0)        
        this.client.room.sendAll([5, 20], data)
        this.lastObjID = struct.unpack("!i", data[:4])[0]        

    def removeObj(this):
        this.client.sendPacket([4, 8], struct.pack("!i?", this.lastObjID, True))

    def playerWin(this):
        timeTaken = int((time.time() - (this.client.playerStartTimeMillis if this.client.room.autoRespawn else this.client.room.gameStartTimeMillis)) * 100)
        place = this.client.room.numCompleted
        if place == 0:
            place = place + 1
        this.client.sendPlayerWin(place, timeTaken)

    def buildConj(this):
        if this.isFireworks == True:
            this.client.sendPacket([4, 14], [int(this.conjX), int(this.conjY)])    

    def removeConj(this):
        if this.isFireworks == True:
            this.client.sendPacket([4, 15], [int(this.conjX), int(this.conjY)])

    def newCoordsConj(this):
        this.conjX = random.randint(0, 79)
        this.conjY = random.randint(2, 39)

    def explosionPlayer(this, posX, posY):
        data = struct.pack("!h", int(posX))
        data += "\x00\x842"
        data += struct.pack("!h?", int(posY), True)
        this.client.sendPacket([5, 17], data)
    
    def moreSettings(this, setting):
        if setting == "giveAdmin":
            if not this.client.Username.lower() in this.client.room.adminsRoom:
                this.client.room.adminsRoom.append(this.client.Username)

        if setting == "join":
            this.sendMessage("<J>Welcome to #utility!")
            this.consoleChat(1, "", ""+str(this.client.Username)+" joined the room.")
            this.client.sendPacket([29, 20], "\x00\x00\x1c\x16\x00t<font color=\'#000000\'><p align=\'center\'><b><font size=\'128\' face=\'Soopafresh,Verdana\'>#utility</font></b></p></font>\x00_\x00d\x02X\x00\xc8\x002FP\x00\x00\x00\x00\x00\x01")
            this.client.sendPacket([29, 20], "\x00\x00\x1c{\x00t<font color=\'#000000\'><p align=\'center\'><b><font size=\'128\' face=\'Soopafresh,Verdana\'>#utility</font></b></p></font>\x00i\x00d\x02X\x00\xc8\x002FP\x00\x00\x00\x00\x00\x01")
            this.client.sendPacket([29, 20], "\x00\x00\x1c\xe0\x00t<font color=\'#000000\'><p align=\'center\'><b><font size=\'128\' face=\'Soopafresh,Verdana\'>#utility</font></b></p></font>\x00d\x00_\x02X\x00\xc8\x002FP\x00\x00\x00\x00\x00\x01")
            this.client.sendPacket([29, 20], "\x00\x00\x1dE\x00t<font color=\'#000000\'><p align=\'center\'><b><font size=\'128\' face=\'Soopafresh,Verdana\'>#utility</font></b></p></font>\x00d\x00i\x02X\x00\xc8\x002FP\x00\x00\x00\x00\x00\x01")
            this.client.sendPacket([29, 20], "\xff\xff\xff\xed\x00W<p align=\'center\'><b><font size=\'128\' face=\'Soopafresh,Verdana\'>#utility</font></b></p>\x00d\x00d\x02X\x00\xc8\x002FP\x00\x00\x00\x00\x00\x01")
            this.client.sendPacket([29, 20], "\xff\xff\xff\xf0\x00\x80<p align=\'center\'><a href=\'#' target='_blank'><b>?</b></a></p>\x00\x05\x00\x1c\x00\x10\x00\x10\x002FP\x002FPd\x00")
            this.client.sendPacket([29, 20], "\xff\xff\xff\xef\x00><p align=\'center\'><a href=\'event:utility:info\'><b><i>i</i></b></a></p>\x00!\x00\x1c\x00\x10\x00\x10\x002FP\x002FPd\x00")            
    
        if setting == "removePopups":        
            popupID = [7190, 7291, 7392, 7493, -19]
            for id in popupID:
                this.removePopups(id)        

    def removePopups(this, popupID):
        this.client.sendPacket([29, 22], struct.pack("!i", popupID))

    def consoleChat(this, type, username, message):
        for client in this.client.room.clients.values():
            if client.Username in this.client.room.adminsRoom:                
                if type == 1:
                    prefix = "<font color='#AAAAAA'>Ξ [Utility] "
                elif type == 2:
                    prefix = "<font color='#AAAAAA'>Ξ ["+str(username)+"] "

                message = prefix + message 
                
                client.sendPacket([6, 9], struct.pack("!h", len(message)) + message)

    def sendMessage(this, message):
        this.client.sendPacket([6, 9], struct.pack("!h", len(message)) + message)

    def staffChat(this, username, message):
        for client in this.client.room.clients.values():
            if client.Username in this.client.room.adminsRoom:
                prefix = "<font color='#00FFFF'>Ξ ["+str(username)+"] "
                client.Utility.sendMessage(prefix + message + "</font>")
    
    def sentCommand(this, command):
        command = command[1:]
        if command == "admins":
            this.consoleChat(2, this.client.Username, "!" + command)
            admins = ', '.join(this.client.room.adminsRoom)
            this.sendMessage("The current room admins are: "+str(admins)+".")            
            this.isCommand = True

        elif command.startswith("admin "):
            playerName = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if playerName in this.client.room.adminsRoom:
                    this.sendMessage(""+str(playerName)+" is already an admin.")
                else:
                    this.client.room.adminsRoom.append(playerName)
                    for client in this.client.room.clients.values():
                        client.Utility.sendMessage(""+str(playerName)+" is now an admin.")
            this.isCommand = True

        elif command.startswith("me "):
            message = command.split(" ")[1]
            if not this.client.Username in this.client.room.playersBan:
                for client in this.client.room.clients.values():
                    client.Utility.sendMessage("<V>*"+str(this.client.Username)+" <N>"+str(message)+"")
            this.isCommand = True

        elif command.startswith("c "):
            message = command.split(" ")[1]
            this.staffChat(this.client.Username, message)
            this.isCommand = True

        elif command.startswith("spawn "):
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                try:
                    objID = command.split(" ")[1]
                except:
                    objID = 0
                try:
                    posX = command.split(" ")[2]
                except:
                    posX = 140
                try:
                    posY = command.split(" ")[3]
                except:
                    posY = 320
                this.spawnObj(objID, posX, posY, 0)
            this.isCommand = True

        elif command == "snow":
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                this.client.room.sendAll([5, 23], struct.pack("!?h", True, 10))
            this.isCommand = True

        elif command.startswith("snow "):            
            event = command.split(" ")[1]
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                if event == "on":
                    this.client.room.sendAll([5, 23], struct.pack("!?h", True, 10))
                elif event == "off":
                    this.client.room.sendAll([5, 23], struct.pack("!?h", False, 10))
            this.isCommand = True

        elif command.startswith("time "):
            time = command.split(" ")[1]
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                try:
                    if time > 32767:
                        time = 32767
                    this.client.room.sendAll([5, 22], struct.pack("!H", int(time)))
                except:
                    time = 32767
                    this.client.room.sendAll([5, 22], struct.pack("!H", int(time)))
            this.isCommand = True

        elif command.startswith("ban "):
            playerName = command.split(" ")[1]
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                if not playerName in this.client.room.playersBan:
                    if playerName in this.client.room.adminsRoom:
                        this.sendMessage(""+str(playerName)+" is an admin and can't be banned.")
                    else:
                        this.client.room.playersBan.append(playerName)
                        for client in this.client.room.clients.values():
                            client.Utility.sendMessage("<R>"+str(playerName)+" has been banned.")            
                else:
                    this.sendMessage(""+str(playerName)+" is already banned.")
            this.isCommand = True

        elif command.startswith("unban "):
            playerName = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if playerName in this.client.room.playersBan:
                    num = None
                    for i, x in enumerate(this.client.room.playersBan):
                        if x == playerName:
                            num = i
                    del this.client.room.playersBan[num]
                    for client in this.client.room.clients.values():
                        client.Utility.sendMessage(""+str(playerName)+" has been unbanned.")
            this.isCommand = True

        elif command == "banlist":
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                banList = ' '.join(this.client.room.playersBan)
                this.sendMessage(str(banList))
            this.isCommand = True

        elif command == "vampire":
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                this.client.room.sendAll([8, 66], struct.pack("!i", this.client.playerCode))
            this.isCommand = True

        elif command.startswith("vampire "):
            event = command.split(" ")[1]
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                if not event in ["me", "all"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            client.room.sendAll([8, 66], struct.pack("!i", client.playerCode))
                elif event == "me":
                    this.client.room.sendAll([8, 66], struct.pack("!i", this.client.playerCode))
                elif event == "all":
                    for client in this.client.room.clients.values():
                        client.room.sendAll([8, 66], struct.pack("!i", client.playerCode))
            this.isCommand = True

        elif command == "name":
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                color = "000000"
                data = struct.pack("!i", this.client.playerCode)
                data += struct.pack("!i", int(color, 16))
                this.client.room.sendAll([29, 4], data)
            this.isCommand = True
                
        elif command.startswith("name "):
            event = command.split(" ")[1]
            try:
                color = command.split(" ")[2]
            except:
                color = "000000"                
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                if not event in ["me", "all"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            data = struct.pack("!i", client.playerCode)
                            data += struct.pack("!i", int(color, 16))
                            client.room.sendAll([29, 4], data)                                                        
                elif event == "me":
                    data = struct.pack("!i", this.client.playerCode)
                    data += struct.pack("!i", int(color, 16))
                    this.client.room.sendAll([29, 4], data)
                elif event == "all":
                    for client in this.client.room.clients.values():
                        data = struct.pack("!i", client.playerCode)
                        data += struct.pack("!i", int(color, 16))
                        client.room.sendAll([29, 4], data)                    
            this.isCommand = True

        elif command.startswith("tp "):
            if this.client.Username in this.client.room.adminsRoom:
                this.consoleChat(2, this.client.Username, "!" + command)
                try:
                    posX = command.split(" ")[1]
                    posY = command.split(" ")[2]
                    if posX == "all":
                        try:
                            posX = command.split(" ")[2]
                            posY = command.split(" ")[3]
                            for client in this.client.room.clients.values():
                                client.room.sendAll([8, 3], struct.pack("!hhih", int(posX), int(posY), 0, 0))
                        except:
                            pass
                    elif not posX.isdigit():
                        try:
                            playerName = command.split(" ")[1]
                            posX = command.split(" ")[2]
                            posY = command.split(" ")[3]
                            for client in this.client.room.clients.values():
                                if playerName == client.Username:
                                    client.room.sendAll([8, 3], struct.pack("!hhih", int(posX), int(posY), 0, 0))                                    
                        except:
                            pass
                    elif posX and posY.isdigit():
                        this.client.room.sendAll([8, 3], struct.pack("!hhih", int(posX), int(posY), 0, 0))
                except:
                    pass
            this.isCommand = True

        elif command == "meep":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.sendPacket([8, 39], "\x01")
            this.isCommand = True

        elif command.startswith("meep "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "me":
                    this.client.sendPacket([8, 39], "\x01")
                elif event == "all":
                    for client in this.client.room.clients.values():
                        client.sendPacket([8, 39], "\x01")
                elif not event in ["me", "all"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            client.sendPacket([8, 39], "\x01")
            this.isCommand = True

        elif command == "disco":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if this.client.room.discoRoom == False:
                    this.client.room.discoRoom = True
                    for client in this.client.room.clients.values():
                        client.reactorDisco()
                elif this.client.room.discoRoom == True:
                    this.client.room.discoRoom = False
            this.isCommand = True

        elif command == "fly":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.isFly = True
                this.client.room.bindKeyBoard(this.client.Username, 32, False, this.client.isFly)
            this.isCommand = True
            
        elif command.startswith("fly "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "me":
                    this.client.isFly = True
                    this.client.room.bindKeyBoard(this.client.Username, 32, False, this.client.isFly)
                elif event == "on":
                    for client in this.client.room.clients.values():
                        client.isFly = True
                        client.room.bindKeyBoard(client.Username, 32, False, client.isFly)
                elif event == "off":
                    for client in this.client.room.clients.values():
                        client.isFly = False                        
                if not event in ["me", "on", "off"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            client.isFly = True
                            client.room.bindKeyBoard(client.Username, 32, False, client.isFly)                
            this.isCommand = True

        elif command == "ffa":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.isFFA = True
                this.client.room.bindKeyBoard(this.client.Username, 40, False, this.client.isFFA)
            this.isCommand = True

        elif command.startswith("ffa "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "me":
                    this.client.isFFA = True
                    this.client.room.bindKeyBoard(this.client.Username, 40, False, this.client.isFFA)
                elif event == "on":
                    for client in this.client.room.clients.values():
                        client.isFFA = True
                        client.room.bindKeyBoard(client.Username, 40, False, client.isFFA)
                elif event == "off":
                    for client in this.client.room.clients.values():
                        client.isFFA = False
                if not event in ["me", "on", "off"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            client.isFFA = True
                            client.room.bindKeyBoard(client.Username, 40, False, client.isFFA)
            this.isCommand = True

        elif command == "shaman":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.sendShamanCode(this.client.playerCode, 0)
            this.isCommand = True

        elif command.startswith("shaman "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "me":
                    this.client.sendShamanCode(this.client.playerCode, 0)
                elif event == "all":
                    for client in this.client.room.clients.values():
                        client.sendShamanCode(client.playerCode, 0)
                if not event in ["me", "all"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            client.sendShamanCode(client.playerCode, 0)
            this.isCommand = True

        elif command in ["np", "map"]:
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.room.mapChange()
            this.isCommand = True

        elif command.startswith("np ") or command.startswith("map "):
            mapCode = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                try:
                    this.client.room.forceNextMap = mapCode
                    this.client.room.mapChange()
                except:
                    pass
            this.isCommand = True

        elif command in ["kill", "mort"]:
            this.consoleChat(2, this.client.Username, "!" + command)
            if not this.client.isDead:
                this.client.isDead = True
                if not this.client.room.noAutoScore: this.client.playerScore += 1
                this.client.sendPlayerDied()
            this.isCommand = True

        elif command.startswith("kill ") or command.startswith("mort "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if event == "me":
                if not this.client.isDead:
                    this.client.isDead = True
                    if not this.client.room.noAutoScore: this.client.playerScore += 1
                    this.client.sendPlayerDied()
            elif event == "all":
                if this.client.Username in this.client.room.adminsRoom:
                    for client in this.client.room.clients.values():
                        if not client.isDead:
                            client.isDead = True
                            if not client.room.noAutoScore: client.playerScore += 1
                            client.sendPlayerDied()
            if not event in ["me", "all"]:
                if this.client.Username in this.client.room.adminsRoom:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            if not client.isDead:
                                client.isDead = True
                                if not client.room.noAutoScore: client.playerScore += 1
                                client.sendPlayerDied()
            this.isCommand = True

        elif command == "cheese":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.room.sendAll([5, 19], [this.client.playerCode])
            this.isCommand = True

        elif command.startswith("cheese "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "me":
                    this.client.room.sendAll([5, 19], [this.client.playerCode])
                elif event == "all":
                    for client in this.client.room.clients.values():
                        client.room.sendAll([5, 19], [client.playerCode])
                if not event in ["me", "all"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            client.room.sendAll([5, 19], [client.playerCode])
            this.isCommand = True

        elif command == "explosion":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if this.canExplosion == False:
                    this.client.isExplosion = True
                    this.client.room.bindMouse(this.client.Username, this.client.isExplosion)
                    this.canExplosion = True
                elif this.canExplosion == True:
                    this.client.isExplosion = False
                    this.client.room.bindMouse(this.client.Username, this.client.isExplosion)
                    this.canExplosion = False
            this.isCommand = True

        elif command.startswith("explosion "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "me":
                    if this.canExplosion == False:
                        this.client.isExplosion = True
                        this.client.room.bindMouse(this.client.Username, this.client.isExplosion)
                        this.canExplosion = True
                    elif this.canExplosion == True:
                        this.client.isExplosion = False
                        this.client.room.bindMouse(this.client.Username, this.client.isExplosion)
                        this.canExplosion = False
                elif event in ["all", "on"]:
                    for client in this.client.room.clients.values():
                        if client.Utility.canExplosion == False:
                            client.isExplosion = True
                            client.room.bindMouse(client.Username, client.isExplosion)
                            client.Utility.canExplosion = True
                        elif client.Utility.canExplosion == True:
                            client.isExplosion = False
                            client.room.bindMouse(client.Username, client.isExplosion)
                            client.Utility.canExplosion = False
                elif event == "off":
                    for client in this.client.room.clients.values():
                        client.isExplosion = False
                        client.room.bindMouse(client.Username, client.isExplosion)
                        client.Utility.canExplosion = False
                if not event in ["me", "all", "on", "off"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            if client.Utility.canExplosion == False:
                                client.isExplosion = True
                                client.room.bindMouse(client.Username, client.isExplosion)
                                client.Utility.canExplosion = True
                            elif client.Utility.canExplosion == True:
                                client.isExplosion = False
                                client.room.bindMouse(client.Username, client.isExplosion)
                                client.Utility.canExplosion = False
            this.isCommand = True
            
        elif command == "pw":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.room.roomPassword = ""
                for client in this.client.room.clients.values():
                    client.Utility.sendMessage("The room's password has been removed.")
            this.isCommand = True

        elif command.startswith("pw "):
            password = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.client.room.roomPassword = str(password)                
                for client in this.client.room.clients.values():
                    client.Utility.sendMessage(""+str(this.client.Username)+" has set a room password.")
                this.sendMessage("The room's password has been set to: "+str(password)+"")
            this.isCommand = True

        elif command == "win":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                this.playerWin()
                this.client.isDead = True
            this.isCommand = True

        elif command.startswith("win "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "me":
                    this.playerWin()
                    this.client.isDead = True
                elif event == "all":
                    for client in this.client.room.clients.values():
                        client.Utility.playerWin()
                        client.isDead = True
                if not event in ["me", "all"]:
                    for client in this.client.room.clients.values():
                        if event == client.Username:
                            client.Utility.playerWin()
                            client.isDead = True
            this.isCommand = True

        elif command == "fireworks":
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:            
                for client in this.client.room.clients.values():
                    client.Utility.isFireworks = True
                    client.fireworksUtility()
            this.isCommand = True

        elif command.startswith("fireworks "):
            event = command.split(" ")[1]
            this.consoleChat(2, this.client.Username, "!" + command)
            if this.client.Username in this.client.room.adminsRoom:
                if event == "off":
                    for client in this.client.room.clients.values():
                        client.Utility.isFireworks = False
                elif event != "off":
                    for client in this.client.room.clients.values():
                        client.Utility.isFireworks = True
                        client.fireworksUtility()
            this.isCommand = True

class PokeLua:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.getFullPokemon = 20
        this.pokeSelect = []
        this.pokeAdmin = []
        this.playersBan = []
        this.pokeName = ""
        this.onlinePokemons = ["Pikachu", "Eevee", "Bulbasaur", "Ivysaur", "Charmander", "Venusaur", "Charmeleon", "Charizard", "Wartortle", "Blastoise", "Caterpie", "Metapod", "Butterfree", "Weedle", "Kakuna", "Beedrill", "Pidgey", "Pidgeotto", "Pidgeot", "Rattata"]
        this.pokeList = {"Pikachu": ["1507b310fa8.png", "1507b30fe8f.png"], "Eevee": ["1507b54756f.png", "1507b5460c9.png"], "Bulbasaur": ["1507b2dabdb.png", "1507b2d9a2d.png"], "Ivysaur": ["1507b2dd037.png", "1507b2dbec0.png"], "Charmander": ["1507b2e16b2.png", "1507b2e05b6.png"], "Venusaur": ["1507b2df4a5.png", "1507b2de388.png"], "Charmeleon": ["1507b2e3922.png", "1507b2e27c9.png"], "Charizard": ["1507b2e5c4c.png", "1507b2e4abb.png"], "Wartortle": ["1507b2ea17b.png", "1507b2e8fbc.png"], "Blastoise": ["1507b2ec390.png", "1507b2eb27f.png"], "Caterpie": ["1507b2ee5e4.png", "1507b2ed4c8.png"], "Metapod": ["1507b2f086b.png", "1507b2ef738.png"], "Butterfree": ["157d3bc0540.png", "1507b2f1946.png"], "Weedle": ["1507b2f51da.png", "1507b2f3d7c.png"], "Kakuna": ["1507b2f7961.png", "1507b2f640f.png"], "Beedrill": ["1507b2f9bde.png", "1507b2f8b00.png"], "Pidgey": ["1507b2fbe1e.png", "1507b2facd2.png"], "Pidgeotto": ["1507b2fe0da.png", "1507b2fcfe2.png"], "Pidgeot": ["1507b30026f.png", "1507b2ff1b9.png"], "Rattata": ["1507b3023f9.png", "1507b30130c.png"]}

    def getAdmin(this):
        if not this.client.Username in this.pokeAdmin:
            this.pokeAdmin.append(this.client.Username)
        this.sendMessage("<ROSE>[A] Voce logou-se na sala como Admin.")

    def addImage(this, imageID, imageName, targetID, playerCode, xPosition, yPosition, targetPlayer):
        p = ByteArray().writeInt(imageID).writeUTF(imageName).writeByte(targetID).writeInt(playerCode).writeShort(xPosition).writeShort(yPosition)
        if targetPlayer == "":
            this.client.sendPacket([29, 19], p.toByteArray())
        else:
            client = this.server.players.get(targetPlayer)
            if client != None:
                client.sendPacket([29, 19], p.toByteArray())

    def removeImage(this, imageID):
        this.client.room.sendAll([29, 18], ByteArray().writeInt(imageID).toByteArray())

    def removeText(this, id):
        this.client.room.sendAll([29, 22], ByteArray().writeInt(id).toByteArray())
        
    def pokeEventKeyboard(this, player, key, down, x, y):
        if key == 39:
            time.sleep(0.1)
            this.removeImage(1)
            time.sleep(0.3)
            try:
                this.addImage(0, this.pokeSelect[0], 3, this.client.playerCode, -45, -45, "")
            except:
                pass
        elif key == 37:
            time.sleep(0.1)
            this.removeImage(0)
            time.sleep(0.3)
            try:
                this.addImage(1, this.pokeSelect[1], 3, this.client.playerCode, -45, -45, "")
            except:
                pass
                
    def pokeCommand(this, command):
        command = command[1:]
        if command.startswith(command):
            pokemon = command
            time.sleep(0.3)
            if this.pokeList.has_key(pokemon):
                this.pokeSelect = this.pokeList[pokemon]
                this.pokeName = pokemon
        if command == "help":
            this.sendMessage("Have <v>15 <bl>commands loaded.")
            this.sendMessage("<vp>- <n>Publics")
            this.sendMessage("<r>- <n>Admin")
            this.sendMessage("<j>- <n>Module Admin\n")
            this.sendMessage("<r>depromote<v>, <r>pw<v>, <j>ban<v>, <r>shaman<v>, <vp>remove<v>, <j>unload<v>, <vp>random<v>, <r>cheese<v>, <r>map<v>, <r>promote<v>, <j>align<v>, <j>unban<v>, <vp>help, <j>pokelist, <vp>banlist")
        if command == "pokelist":
            this.sendMessage("<B>Pokemon's list: </B>")
            poke = ', '.join(this.onlinePokemons)
            this.sendMessage("-> "+str(poke)+"")
        if command == "shaman":
            if this.client.Username in this.pokeAdmin:
                this.client.sendShamanCode(this.client.playerCode, 0)
        if command.startswith("ban "):
            playerName = command.split(" ")[1]
            if this.client.Username in this.pokeAdmin:
                if not playerName in this.playersBan:
                    if playerName in this.pokeAdmin:
                        this.sendMessage(""+str(playerName)+" é um administrador e nao pode ser banido.")
                    else:
                        this.playersBan.append(playerName)
                        for client in this.client.room.clients.values():
                            client.Pokelua.sendMessage("<R>"+str(playerName)+" foi banido.")
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.sendMessage("Você está banido da sala: <J>"+str(this.client.room.roomName)+"</J>.")
                            player.enterRoom("1")
                else:
                    this.sendMessage(""+str(playerName)+" já está banido.")
            else:
                this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
        if command.startswith("unban "):
            playerName = command.split(" ")[1]
            if this.client.Username in this.pokeAdmin:
                if playerName in this.playersBan:
                    num = None
                    for i, x in enumerate(this.playersBan):
                        if x == playerName:
                            num = i
                    del this.playersBan[num]
                    for client in this.client.room.clients.values():
                        client.Pokelua.sendMessage(""+str(playerName)+" foi desbanido.")
            else:
                this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
        if command == "banlist":
            if this.client.Username in this.pokeAdmin:
                banList = ', '.join(this.playersBan)
                this.sendMessage(str(banList))
        if command == "random":
            pokemons = this.onlinePokemons
            poke = random.choice(pokemons)
            time.sleep(0.3)
            if this.pokeList.has_key(poke):
                this.pokeSelect = this.pokeList[poke]
                this.pokeName = poke
        if command.startswith("promote"):
            try:
                if this.client.Username in this.pokeAdmin:
                    playerName = command.split(" ")[1]
                    player = this.server.players.get(playerName)
                    if player != None:
                        if this.client.Username in this.pokeAdmin:
                            if playerName in this.pokeAdmin:
                                this.sendMessage(""+str(playerName)+" is already an admin.")
                            else:
                                this.pokeAdmin.append(playerName)
                                for client in this.client.room.clients.values():
                                    client.sendMessage("[#PokeLua#] - ["+str(playerName)+"] agora é um administrador.")
                                    this.sendMessage("<font color='#B40404'>[~A:EXEC:"+this.client.Username+"] </font><font color='#FE2E2E'>promoveu "+playerName+"</font>")
                    else:
                        this.sendMessage("Nome: "+playerName+" está offline na sala")
                else:
                    this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
            except:
                this.sendMessage("Comando desconhecido, use !help")
        if command.startswith("depromote"):
            try:
                if this.client.Username in this.pokeAdmin:
                    playerName = command.split(" ")[1]
                    player = this.server.players.get(playerName)
                    if player != None:
                        if this.client.Username in this.pokeAdmin:
                            this.pokeAdmin.remove(playerName)
                            for client in this.client.room.clients.values():
                                client.sendMessage("[#PokeLua#] - ["+str(playerName)+"] foi removido da administração desta sala.")
                                this.sendMessage("<font color='#B40404'>[~A:EXEC:"+this.client.Username+"] </font><font color='#FE2E2E'>despromoveu "+playerName+"</font>")
                    else:
                        this.sendMessage("Nome: "+playerName+" está offline na sala")
                else:
                    this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
            except:
                this.sendMessage("Comando desconhecido, use !help")
        if command == "cheese":
            if this.client.Username in this.pokeAdmin:
                this.client.room.sendAll([5, 19], [this.client.playerCode])
                this.sendMessage("<font color='#B40404'>[~A:EXEC:"+this.client.Username+"] </font><font color='#FE2E2E'>Queijo</font>")
            else:
                this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
        if command == "map":
            if this.client.Username in this.pokeAdmin:
                this.client.room.killAll()
                this.sendMessage("<font color='#B40404'>[~A:EXEC:"+this.client.Username+"] </font><font color='#FE2E2E'>map</font>")
            else:
                this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
        if command == "pw":
            if this.client.Username in this.pokeAdmin:
                this.client.room.roomPassword = ""
                this.sendMessage("Por favor, digite uma senha.")
                this.sendMessage("<font color='#B40404'>[~A:EXEC:"+this.client.Username+"] </font><font color='#FE2E2E'>Senha</font>")
            else:
                this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
        if command.startswith("pw "):
            try:
                if this.client.Username in this.pokeAdmin:                
                    password = command.split(" ")[1]
                    this.client.room.roomPassword = password
                    this.sendMessage("<font color='#B40404'>[~A:LOG] </font><font color='#FE2E2E'>Senha da sala: "+password+"</font>")
                    this.sendMessage("<font color='#B40404'>[~A:EXEC:"+this.client.Username+"] </font><font color='#FE2E2E'>Senha: "+password+"</font>")
                else:
                    this.sendMessage("Você não tem direitos suficientes. Você precisa de direitos de administrador.")
            except:
                this.sendMessage("Comando desconhecido, use !help")

    def startGame(this):
        this.sendOpenPanel()

    def sendOpenPanel(this):
        admins = ', '.join(this.pokeAdmin)
        text = "<J><b>PokeLua</b> The module has started!\n\n<V><b>Langue:</b> <N>"+str(this.client.Langue)+"\n<V><b>Pokemons loaded</b> <N>"+str(this.getFullPokemon)+"\n\n<V><b>ADMNIS: "+str(admins)+"</b>\n<V><b>"+str(this.client.Username)+"</b> => <j>"+str(this.pokeName)
        this.client.sendAddPopupText(7485, 560, 30, 230, 100, '2E2E2E', '151515', 60, str(text)) 

    def sendMessage(this, message):
        this.client.sendPacket([6, 9], ByteArray().writeUTF(message).toByteArray())