#coding: utf-8
import time, random, thread, urllib2, smtplib

# Library
from twisted.internet import reactor

# Utils
from utils import *

class config:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        currentPage = 1

    def close(this):
        i = 1
        while i <= 14999:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1
        this.client.sendMenu()

    def close2(this):
        i = 1
        while i <= 14999:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def closeFFARaceInformation(this):
        i = 150
        while i <= 174:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def closeoption(this):
        i = 10004
        while i <= 10005:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def open(this):
        this.close2()
        text = "<p align='center'><font size='20' color='#990000'>Configurações do seu jogo</font></p>"
        text += "\n<font size='18'>-</font> <font size='13'><a href='event:config:music'>Música</a></font>"
        text += "\n<font size='18'>-</font> <font size='13'><a href='event:config:personalizacao'>Personalização</a></font>"
        this.client.room.addTextArea(10002, str(text), this.client.Username, 64, 46, 680, 320, 0x000000, 0x313131, 95, False)
        this.client.room.addTextArea(10003, "<font size='28' color='#990000'><a href='event:config:close'>X</a></font>", this.client.Username, 754, 40, 50, 50, 0, 0, 0, False)

    def options(this, id=0, option1="", option2="", option3="", option4="", option5=""):
        id = "Cor do nome <J>(VIP)</J>" if id == 1 else "Música" if id == 2 else "Nome da música flutuando" if id == 3 else ""
        opt = "Escolha uma das opções abaixo: "+str(id)+"\n"
        opt += "\n<font size='18'>-</font> <font size='13'>"+str(option1)+"</font>" if option1 != "" else ""
        opt += "\n<font size='18'>-</font> <font size='13'>"+str(option2)+"</font>" if option2 != "" else ""
        opt += "\n<font size='18'>-</font> <font size='13'>"+str(option3)+"</font>" if option3 != "" else ""
        opt += "\n<font size='18'>-</font> <font size='13'>"+str(option4)+"</font>" if option4 != "" else ""
        opt += "\n<font size='18'>-</font> <font size='13'>"+str(option5)+"</font>" if option5 != "" else ""
        this.client.room.addTextArea(10004, str(opt), this.client.Username, 280, 150, 260, 140, 0x000000, 0xFFFFFF, 95, False)
        this.client.room.addTextArea(10005, "<font size='28' color='#990000'><a href='event:config:closeoption'>X</a></font>", this.client.Username, 548, 146, 50, 50, 0, 0, 0, False)

    def personalizationopen(this):
        text = "<p align='center'><font size='20' color='#990000'>Personalize seu jogo</font></p>"
        text += "\n<font size='18'>-</font> <font size='13'><a href='event:config:colormouse'>Cor do rato</a></font>"
        text += "\n<font size='18'>-</font> <font size='13'><a href='event:config:colornick'>Cor do nome <J>(VIP)</J></a></font>"
        #text += "\n<font size='18'>-</font> <font size='13'><a href='event:config:musicname'>Nome da música flutuando</a></font>"
        this.client.room.addTextArea(10006, str(text), this.client.Username, 420, 94, 300, 240, 0x000000, 0x313131, 95, False)

    def musicname(this, enable = 1):
        if enable == 0:
            this.client.room.addTextArea(15000, "", this.client.Username, 0, 0, 0, 0, 0, 0, 0, False)
        else:
            if enable == 1 and this.client.musicOn == 1:
                if this.client.musicNameLink != "":
                    this.client.room.addTextArea(15000, "", this.client.Username, 0, 0, 0, 0, 0, 0, 0, False)
                    info = urllib2.urlopen(this.client.musicNameLink)
                    this.client.room.addTextArea(15000, "<marquee direction='right'>"+str(info.read())+"</marquee>", this.client.Username, 6, 379, 224, 18, 0x000000, 0x313131, 95, False)
                    reactor.callLater(1.2, this.musicname)
            else:
                this.client.sendMessage("<R>Ligue a rádio para usar essa função.")

            if this.client.musicNameLink == "" and this.client.musicOn == 1 and enable == 1:
                this.client.sendMessage("<R>Função indisponível para está rádio.")
                this.client.room.addTextArea(15000, "", this.client.Username, 0, 0, 0, 0, 0, 0, 0, False)
                reactor.callLater(1.2, this.musicname, 0)

    def FFARaceHelp(this, id):
        pass

class ranking:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        currentPage = 1

    def close(this):
        i = 1
        while i <= 14999:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1
        this.client.sendMenu()

    def close2(this):
        i = 1
        while i <= 14999:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def open(this):
        this.close2()
        this.client.room.addTextArea(10002, "", this.client.Username, 4, 25, 792, 410, 0x000008, 0x000000, 92, False)
        this.client.room.addTextArea(10003, "<p align='center'><font size='22' family='Arial' color='#BEBB56'><a href='#'><b>Ranking "+str(this.server.miceName)+"</b></a></font></p>", this.client.Username, 235, 27, 340, 45, 0, 0, 100, False)
        this.client.room.addTextArea(10016, "<font size='23' color='#990000'><a href='event:ranking:close'>X</a></font>", this.client.Username, 762, 34, 50, 50, 0, 0, 0, False)

        # Firsts
        this.client.room.addTextArea(10004, "<p align='center'><font size='11'><BV><b>First</b></BV></font></p>", this.client.Username, -82, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, FirstCount from Users where PrivLevel < 12 ORDER By FirstCount DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        posfirsts2 = 1
        textfirsts = ""
        firsts = ""
        this.client.updateDatabase()
        for rrf in rs:
            posfirsts = "0"+str(posfirsts2) if posfirsts2 <= 9 else posfirsts2
            playerName = str(rrf[0])
            firstCount = rrf[1]
            if posfirsts2 == 1:
                textfirsts += "<font size='11' color='#FADE55'>"+str(posfirsts)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textfirsts += "<br />"
            elif posfirsts2 == 2:
                textfirsts += "<font size='11' color='#EFEBE0'>"+str(posfirsts)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textfirsts += "<br />"
            elif posfirsts2 == 3:
                textfirsts += "<font size='11' color='#B44F0D'>"+str(posfirsts)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textfirsts += "<br />"
            else:
                textfirsts += "<font size='11'><CH>"+str(posfirsts)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                textfirsts += "<br />"
            firsts += "<V>"+str(firstCount)+"</V>\n"
            this.client.room.addTextArea(10005, str(textfirsts), this.client.Username, 8, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10006, str(firsts), this.client.Username, 135, 107, 340, 420, 0, 0, 100, False)
            posfirsts2 += 1

        # Queijos
        this.client.room.addTextArea(10007, "<p align='center'><font size='11'><BV><b>Queijos</b></BV></font></p>", this.client.Username, 117, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, CheeseCount from Users where PrivLevel < 12 ORDER By CheeseCount DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        poscheeses2 = 1
        textcheeses = ""
        cheeses = ""
        this.client.updateDatabase()
        for rrf in rs:
            poscheeses = "0"+str(poscheeses2) if poscheeses2 <= 9 else poscheeses2
            playerName = str(rrf[0])
            cheeseCount = rrf[1]
            if poscheeses2 == 1:
                textcheeses += "<font size='11' color='#FADE55'>"+str(poscheeses)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textcheeses += "<br />"
            elif poscheeses2 == 2:
                textcheeses += "<font size='11' color='#EFEBE0'>"+str(poscheeses)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textcheeses += "<br />"
            elif poscheeses2 == 3:
                textcheeses += "<font size='11' color='#B44F0D'>"+str(poscheeses)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textcheeses += "<br />"
            else:
                textcheeses += "<font size='11'><CH>"+str(poscheeses)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                textcheeses += "<br />"
            cheeses += "<V>"+str(cheeseCount)+"</V>\n"
            this.client.room.addTextArea(10008, str(textcheeses), this.client.Username, 203, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10009, str(cheeses), this.client.Username, 350, 107, 340, 420, 0, 0, 100, False)
            poscheeses2 += 1

        # Saves
        this.client.room.addTextArea(10010, "<p align='center'><font size='11'><BV><b>Saves</b></BV></font></p>", this.client.Username, 333, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, ShamanSaves from Users where PrivLevel < 12 ORDER By ShamanSaves DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        possaves2 = 1
        textsaves = ""
        saves = ""
        this.client.updateDatabase()
        for rrf in rs:
            possaves = "0"+str(possaves2) if possaves2 <= 9 else possaves2
            playerName = str(rrf[0])
            savesCount = rrf[1]
            if possaves2 == 1:
                textsaves += "<font size='11' color='#FADE55'>"+str(possaves)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textsaves += "<br />"
            elif possaves2 == 2:
                textsaves += "<font size='11' color='#EFEBE0'>"+str(possaves)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textsaves += "<br />"
            elif possaves2 == 3:
                textsaves += "<font size='11' color='#B44F0D'>"+str(possaves)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textsaves += "<br />"
            else:
                textsaves += "<font size='11'><CH>"+str(possaves)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                textsaves += "<br />"
            saves += "<V>"+str(savesCount)+"</V>\n"
            this.client.room.addTextArea(10011, str(textsaves), this.client.Username, 427, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10012, str(saves), this.client.Username, 556, 107, 340, 420, 0, 0, 100, False)
            possaves2 += 1

        # Bootcamps
        this.client.room.addTextArea(10013, "<p align='center'><font size='11'><BV><b>Bootcamp</b></BV></font></p>", this.client.Username, 517, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, BootcampCount from Users where PrivLevel < 12 ORDER By BootcampCount DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        posbootcamps2 = 1
        textbootcamps = ""
        bootcamps = ""
        this.client.updateDatabase()
        for rrf in rs:
            posbootcamps = "0"+str(posbootcamps2) if posbootcamps2 <= 9 else posbootcamps2
            playerName = str(rrf[0])
            bootcampCount = rrf[1]
            if posbootcamps2 == 1:
                textbootcamps += "<font size='11' color='#FADE55'>"+str(posbootcamps)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textbootcamps += "<br />"
            elif posbootcamps2 == 2:
                textbootcamps += "<font size='11' color='#EFEBE0'>"+str(posbootcamps)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textbootcamps += "<br />"
            elif posbootcamps2 == 3:
                textbootcamps += "<font size='11' color='#B44F0D'>"+str(posbootcamps)+"</font> <V>-</V> "+str(playerName)+"</font>"
                textbootcamps += "<br />"
            else:
                textbootcamps += "<font size='11'><CH>"+str(posbootcamps)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                textbootcamps += "<br />"
            bootcamps += "<V>"+str(bootcampCount)+"</V>\n"
            this.client.room.addTextArea(10014, str(textbootcamps), this.client.Username, 613, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10015, str(bootcamps), this.client.Username, 749, 107, 340, 420, 0, 0, 100, False)
            posbootcamps2 += 1

class email:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        currentPage = 1

    def close(this):
        i = 1
        while i <= 14999:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def openConfirmationBox(this):
        this.close()
        text = "<p align='center'><font size='20' color='#990000'>Confirme seu endereço de email</font></p>"
        text += "\n<font size='15'>Clique <a href='event:email:resend'>aqui</a> para reenviar o código para seu endereço de email.</font>"
        text += "\n<font size='15'>Para confirmar seu endereço de email:</font>"
        text += "\n<font size='13'>1. Entre no email que você usou para criar sua conta.</font>"
        text += "\n<font size='13'>2. Copie o código enviado para o seu email e digite na caixa de texto abaixo.</font>"
        text += "\n<font size='13'>3. Pronto, desfrute dos nossos sistemas e seja feliz!</font>"
        this.client.room.addTextArea(10002, str(text), this.client.Username, 64, 46, 680, 128, 0x000000, 0x313131, 95, False)
        this.client.room.addPopup(10004, 2, "Digite o código recebido em seu email!\n <center>Ex: B2HGDA87Y.</center>", this.client.Username, 280, 181, 240, True)
        this.client.room.addTextArea(10003, "<font size='28' color='#990000'><a href='event:email:close'>X</a></font>", this.client.Username, 754, 40, 50, 50, 0, 0, 0, False)

    def sendCode(this):
        code = TFMUtils.getRandomChars(random.randint(8,10))
        this.client.codeEmailConfirmation = str(code)

        # Credenciais
        remetente    = 'andrielkogama@gmail.com'
        senha        = 'andriel2004'

        # Informações da mensagem
        destinatario = str(this.client.emailAddress)
        assunto      = 'Confirme sua conta do '+str(this.server.miceName)
        texto        = 'Caro '+str(this.client.Username)+', confirme sua conta do '+str(this.server.miceName)+' usando o seguinte código abaixo: \n'+str(code)+' \nDivirta-se desfrutando de nossos sistemas!'

        # Preparando a mensagem
        msg = '\r\n'.join([
          'From: %s' % remetente,
          'To: %s' % destinatario,
          'Subject: %s' % assunto,
          '',
          '%s' % texto
          ])

        # Enviando o email
        server = smtplib.SMTP('smtp.gmail.com:587')
        server.starttls()
        server.login(remetente,senha)
        server.sendmail(remetente, destinatario, msg)
        server.quit()

        this.client.sendMessage("<BL>Verifique seu endereço de email!")
        this.client.updateDatabase()

class radios:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor
        currentPage = 1
        
    def open(this):
        this.client.room.addTextArea(13000, "<p align='center'><img src='https://i.imgur.com/feG3iCj.png' hspace='0' vspace='-2'>", this.client.Username, 180, 15, 455, 370, 0, 0, 0, False)
        this.client.room.addTextArea(13001, "<p align='center'><N>Olá <J>"+str(this.client.Username)+"</J>, bem-vindo ao reprodutor de músicas do "+str(this.server.miceName)+"!", this.client.Username, 220, 100, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13002, "<p align='center'><N>Todas as rádios estão em Português.", this.client.Username, 220, 130, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13003, "<p align='center'><N>Desfrute do nosso sistema abaixo!", this.client.Username, 220, 160, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13004, "<p align='center'><N>Escolha uma das opções de rádio acima.", this.client.Username, 220, 325, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13005, "<p align='center'><img src='https://i.imgur.com/eQmi5zW.png'>", this.client.Username, 335, 180, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13006, "<p align='center'><img src='https://i.imgur.com/eQmi5zW.png'>", this.client.Username, 335, 215, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13007, "<p align='center'><img src='https://i.imgur.com/eQmi5zW.png'>", this.client.Username, 335, 250, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13008, "<p align='center'><img src='https://i.imgur.com/eQmi5zW.png'>", this.client.Username, 335, 285, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13009, "<p align='center'><img src='https://i.imgur.com/eQmi5zW.png'>", this.client.Username, 465, 285, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13010, "<N><a href='event:config:music:funk'>FUNK</a>", this.client.Username, 375, 193, 50, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13011, "<N><a href='event:config:music:eletronica'>ELETRÔNICA</a>", this.client.Username, 357, 230, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13012, "<N><a href='event:config:music:sertaneja'>SERTANEJA</a>", this.client.Username, 359, 265, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13013, "<N><a href='event:config:music:rap'>RAP</a>", this.client.Username, 380, 300, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13014, "<N><a href='event:config:music:off'>DESLIGAR</a>", this.client.Username, 497, 300, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13015, "<R><font size='14'><b><a href='event:config:close2'>X</a></b></font></R>", this.client.Username, 192, 54, 34, 34, 0, 0, 0, False)
