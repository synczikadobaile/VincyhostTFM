# coding: utf-8
import time as thetime, random, time, re, xml.etree.ElementTree as xml, xml.parsers.expat

from datetime import datetime

class TFMUtils:
    @staticmethod
    def getTFMLangues(langueID):
        return {0:"EN", 1:"FR", 2:"FR", 3:"BR", 4:"ES", 5:"CN", 6:"TR", 7:"VK", 8:"PL", 9:"HU", 10:"NL", 11:"RO", 12:"ID", 13:"DE", 14:"E2", 15:"AR", 16:"PH", 17:"LT", 18:"JP", 19:"CH", 20:"FI", 21:"CZ", 22:"SK", 23:"HR", 24:"BU", 25:"LV", 26:"HE", 27:"IT", 29:"ET", 30:"AZ", 31:"PT"}[langueID]

    @staticmethod
    def getTime():
        return int(long(str(time.time())[:10]))

    @staticmethod
    def checkValidXML(XML):
        if re.search("ENTITY", XML) and re.search("<html>", XML):
            return False
        else:
            try:
                parser = xml.parsers.expat.ParserCreate()
                parser.Parse(XML)
                return True
            except Exception, e:
                return False

    @staticmethod
    def getHoursDiff(endTimeMillis):
        startTime = TFMUtils.getTime()
        startTime = datetime.fromtimestamp(float(startTime))
        endTime = datetime.fromtimestamp(float(endTimeMillis))
        result = endTime - startTime
        seconds = (result.microseconds + (result.seconds + result.days * 24 * 3600) * 10 ** 6) / float(10 ** 6)
        hours = int(int(seconds) / 3600) + 1
        return hours

    @staticmethod
    def getDiffDays(time):
        return time - TFMUtils.getTime() / (24 * 60 * 60)

    @staticmethod
    def getSecondsDiff(endTimeMillis):
        return int(long(str(thetime.time())[:10]) - endTimeMillis)

    @staticmethod
    def getRandomChars(size):
        return "".join((random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789") for x in range(size)))

    @staticmethod
    def calculateTime(time):
        diff = int(time) - TFMUtils.getTime()
        diffSeconds = diff / 1000 % 60
        diffMinutes = diff / (60 * 1000) % 60
        diffHours = diff / (60 * 60 * 1000) % 24
        diffDays = diff / (24 * 60 * 60 * 1000)
        return diffDays <= 0 and diffHours <= 0 and diffMinutes <= 0 and diffSeconds <= 0

    @staticmethod
    def parsePlayerName(playerName):
        if "@" in playerName:
            return playerName
        else:
            return (playerName[0] + playerName[1:].lower().capitalize()) if playerName.startswith("*") or playerName.startswith("+") else playerName.lower().capitalize()

    @staticmethod
    def joinWithQuotes(list):
        return "\"" + "\", \"".join(list) + "\""

    @staticmethod
    def getValue(*array):
        return random.choice(array)

    @staticmethod
    def getYoutubeID(url):
        matcher = re.compile(".*(?:youtu.be\\/|v\\/|u\\/\\w\\/|embed\\/|watch\\?v=)([^#\\&\\?]*).*").match(url)
        return matcher.group(1) if matcher else None

    @staticmethod
    def Duration(duration):
        time = re.compile('P''(?:(?P<years>\d+)Y)?''(?:(?P<months>\d+)M)?''(?:(?P<weeks>\d+)W)?''(?:(?P<days>\d+)D)?''(?:T''(?:(?P<hours>\d+)H)?''(?:(?P<minutes>\d+)M)?''(?:(?P<seconds>\d+)S)?'')?').match(duration).groupdict()
        for key in time.items():
            time[key[0]] = 0 if key[1] is None else time[key[0]]
        return (int(time["weeks"]) * 7 * 24 * 60 * 60) + (int(time["days"]) * 24 * 60 * 60) + (int(time["hours"]) * 60 * 60) + (int(time["minutes"]) * 60) + (int(time["seconds"]) - 1)
